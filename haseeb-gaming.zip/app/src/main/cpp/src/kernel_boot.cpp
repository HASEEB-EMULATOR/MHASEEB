#include "haseeb/kernel_boot.hpp"
#include "haseeb/guest_vfs_bridge.hpp"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstring>
#include <fcntl.h>
#include <iomanip>
#include <random>
#include <sstream>
#include <sys/stat.h>
#include <unistd.h>

namespace haseeb::vm {

namespace {

inline constexpr uint16_t kElfEtExec = 2u;
inline constexpr uint16_t kElfEtDyn  = 3u;
inline constexpr uint16_t kElfEmAarch64 = 183u;
inline constexpr uint32_t kPtLoad = 1u;
inline constexpr uint32_t kPtInterp = 3u;
inline constexpr uint32_t kPtTls = 7u;
inline constexpr uint32_t kPfX = 1u;
inline constexpr uint32_t kPfW = 2u;
inline constexpr uint64_t kInterpLoadBase = 0x0000000020000000ULL;

#pragma pack(push, 1)
struct Elf64Ehdr {
    uint8_t  e_ident[16];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint64_t e_entry;
    uint64_t e_phoff;
    uint64_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
};

struct Elf64Phdr {
    uint32_t p_type;
    uint32_t p_flags;
    uint64_t p_offset;
    uint64_t p_vaddr;
    uint64_t p_paddr;
    uint64_t p_filesz;
    uint64_t p_memsz;
    uint64_t p_align;
};
#pragma pack(pop)

uint64_t AlignDown4K(uint64_t v) { return v & ~0xFFFULL; }
uint64_t AlignUp4K(uint64_t v) { return (v + 0xFFFULL) & ~0xFFFULL; }

int64_t NowSteadyNs() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
               std::chrono::steady_clock::now().time_since_epoch())
        .count();
}

bool AllocZeroPage(GuestRam& ram, uint64_t& cursor, uint64_t limit, uint64_t& out_pa) {
    cursor = AlignUp4K(cursor);
    if (cursor + 4096ULL > limit) return false;
    uint8_t zeros[4096]{};
    if (!ram.WriteBytes(cursor, zeros, sizeof(zeros))) return false;
    out_pa = cursor;
    cursor += 4096ULL;
    return true;
}

std::string NormalizeGuestPath(const std::string& raw) {
    if (raw.empty()) return "/";
    std::string clean;
    for (char c : raw) {
        if (c == '/' && !clean.empty() && clean.back() == '/') continue;
        clean.push_back(c);
    }
    if (clean.front() != '/') clean.insert(clean.begin(), '/');
    while (clean.size() > 1u && clean.back() == '/') clean.pop_back();
    return clean;
}

bool MapElfSegments(GuestRam& ram,
                    uint64_t ttbr0_pa,
                    uint64_t& phys_alloc_cursor,
                    uint64_t phys_alloc_limit,
                    const std::vector<uint8_t>& elf_bytes,
                    const Elf64Ehdr& eh,
                    uint64_t load_bias,
                    uint64_t& out_first_pt_load_va,
                    bool& out_has_pt_load,
                    uint64_t& inout_highest_va,
                    std::string& out_error) {
    std::unordered_map<uint64_t, uint64_t> mapped_va_to_pa;
    out_has_pt_load = false;
    out_first_pt_load_va = 0ULL;

    for (uint16_t i = 0; i < eh.e_phnum; ++i) {
        Elf64Phdr ph{};
        std::memcpy(&ph, elf_bytes.data() + eh.e_phoff + static_cast<size_t>(i) * eh.e_phentsize, sizeof(ph));
        if (ph.p_type != kPtLoad || ph.p_memsz == 0) continue;
        if (ph.p_offset + ph.p_filesz > elf_bytes.size()) {
            out_error = "ELF64 PT_LOAD segment out of file bounds";
            return false;
        }

        const uint64_t seg_va = load_bias + ph.p_vaddr;
        if (!out_has_pt_load) {
            out_first_pt_load_va = AlignDown4K(seg_va);
            out_has_pt_load = true;
        }
        const uint64_t page_start = AlignDown4K(seg_va);
        const uint64_t page_end = AlignUp4K(seg_va + ph.p_memsz);
        if (load_bias < kInterpLoadBase && page_end > inout_highest_va) {
            inout_highest_va = page_end;
        }

        const bool writable = (ph.p_flags & kPfW) != 0;
        const bool executable = (ph.p_flags & kPfX) != 0;

        for (uint64_t va = page_start; va < page_end; va += 4096ULL) {
            uint64_t pa = 0;
            auto it = mapped_va_to_pa.find(va);
            if (it == mapped_va_to_pa.end()) {
                if (!AllocZeroPage(ram, phys_alloc_cursor, phys_alloc_limit, pa)) {
                    out_error = "Out of guest RAM while mapping ELF64 segment";
                    return false;
                }
                mapped_va_to_pa[va] = pa;
            } else {
                pa = it->second;
            }
            if (!Elf64GuestLoader::MapPage4K(ram, ttbr0_pa, phys_alloc_cursor, phys_alloc_limit,
                                             va, pa, true, writable, executable)) {
                out_error = "Failed installing Stage-1 page table entry for ELF64";
                return false;
            }
        }

        uint64_t copied = 0;
        while (copied < ph.p_filesz) {
            const uint64_t cur_va = seg_va + copied;
            const uint64_t va_pg = AlignDown4K(cur_va);
            const uint64_t pg_off = cur_va - va_pg;
            const size_t chunk = static_cast<size_t>(
                std::min<uint64_t>(4096ULL - pg_off, ph.p_filesz - copied));
            uint64_t pa = mapped_va_to_pa.at(va_pg);
            if (!ram.WriteBytes(pa + pg_off, elf_bytes.data() + ph.p_offset + copied, chunk)) {
                out_error = "Failed writing ELF64 segment bytes to guest RAM";
                return false;
            }
            copied += chunk;
        }
    }
    return true;
}

// Clones an EL0 address space for POSIX fork(): shares RX/RO & EL1 VBAR pages,
// deep-copies writable EL0 stack/data pages so parent and child never corrupt each other.
bool CloneUserAddressSpace(GuestRam& ram,
                           uint64_t src_ttbr0_pa,
                           uint64_t& dst_ttbr0_pa,
                           uint64_t& phys_cursor,
                           uint64_t phys_limit) {
    if (!AllocZeroPage(ram, phys_cursor, phys_limit, dst_ttbr0_pa)) {
        return false;
    }
    uint8_t copy_buf[4096];
    for (uint64_t l1 = 0; l1 < 512ULL; ++l1) {
        uint64_t d1 = 0;
        if (!ram.ReadU64(src_ttbr0_pa + l1 * 8ULL, d1) || (d1 & 3ULL) != 3ULL) continue;
        const uint64_t l2_pa = d1 & 0x0000FFFFFFFFF000ULL;
        for (uint64_t l2 = 0; l2 < 512ULL; ++l2) {
            uint64_t d2 = 0;
            if (!ram.ReadU64(l2_pa + l2 * 8ULL, d2) || (d2 & 3ULL) != 3ULL) continue;
            const uint64_t l3_pa = d2 & 0x0000FFFFFFFFF000ULL;
            for (uint64_t l3 = 0; l3 < 512ULL; ++l3) {
                uint64_t leaf = 0;
                if (!ram.ReadU64(l3_pa + l3 * 8ULL, leaf) || (leaf & 3ULL) != 3ULL) continue;
                const uint64_t va = (l1 << 30) | (l2 << 21) | (l3 << 12);
                const uint64_t pa = leaf & 0x0000FFFFFFFFF000ULL;
                const bool el0_access = (leaf & (1ULL << 6)) != 0ULL;
                const bool writable = (leaf & (1ULL << 7)) == 0ULL;
                const bool executable = el0_access ? ((leaf & (1ULL << 54)) == 0ULL)
                                                   : ((leaf & (1ULL << 53)) == 0ULL);

                uint64_t target_pa = pa;
                if (el0_access && writable && !executable) {
                    if (!AllocZeroPage(ram, phys_cursor, phys_limit, target_pa)) return false;
                    if (!ram.ReadBytes(pa, copy_buf, sizeof(copy_buf)) ||
                        !ram.WriteBytes(target_pa, copy_buf, sizeof(copy_buf))) {
                        return false;
                    }
                }
                if (!Elf64GuestLoader::MapPage4K(ram, dst_ttbr0_pa, phys_cursor, phys_limit,
                                                 va, target_pa, el0_access, writable, executable)) {
                    return false;
                }
            }
        }
    }
    return true;
}

const char* ExceptionClassName(uint32_t ec_val) {
    switch (ec_val) {
        case ec::kUnknown:       return "UNKNOWN_INSN";
        case ec::kTrapWfiWfe:    return "TRAP_WFI_WFE";
        case ec::kFpSimdAccess:  return "FP_SIMD_DISABLED";
        case ec::kIllegalState:  return "ILLEGAL_EXEC_STATE";
        case ec::kSvc64:         return "SVC64";
        case ec::kHvc64:         return "HVC64";
        case ec::kSmc64:         return "SMC64";
        case ec::kSysRegTrap:    return "SYSREG_TRAP";
        case ec::kInsnAbortLow:  return "INSN_ABORT_EL0";
        case ec::kInsnAbortSame: return "INSN_ABORT_EL1";
        case ec::kPcAlign:       return "PC_ALIGNMENT";
        case ec::kDataAbortLow:  return "DATA_ABORT_EL0";
        case ec::kDataAbortSame: return "DATA_ABORT_EL1";
        case ec::kSpAlign:       return "SP_ALIGNMENT";
        case ec::kBrk64:         return "BRK_TRAP";
        default:                 return "SYNC_TRAP";
    }
}

} // namespace

bool Elf64GuestLoader::IsValidAArch64Elf(const std::vector<uint8_t>& elf_bytes) {
    if (elf_bytes.size() < sizeof(Elf64Ehdr)) return false;
    Elf64Ehdr eh{};
    std::memcpy(&eh, elf_bytes.data(), sizeof(eh));
    return eh.e_ident[0] == 0x7Fu && eh.e_ident[1] == 'E' &&
           eh.e_ident[2] == 'L' && eh.e_ident[3] == 'F' &&
           eh.e_ident[4] == 2u && eh.e_ident[5] == 1u &&
           eh.e_machine == kElfEmAarch64 &&
           (eh.e_type == kElfEtExec || eh.e_type == kElfEtDyn);
}

bool Elf64GuestLoader::MapPage4K(GuestRam& ram,
                                 uint64_t ttbr0_pa,
                                 uint64_t& phys_alloc_cursor,
                                 uint64_t phys_alloc_limit,
                                 uint64_t va,
                                 uint64_t pa,
                                 bool el0_access,
                                 bool writable,
                                 bool executable) {
    const uint64_t l1_idx = (va >> 30) & 0x1FFULL;
    const uint64_t l2_idx = (va >> 21) & 0x1FFULL;
    const uint64_t l3_idx = (va >> 12) & 0x1FFULL;

    auto ensure_table = [&](uint64_t table_pa, uint64_t idx, uint64_t& next_table_pa) -> bool {
        uint64_t desc = 0;
        if (!ram.ReadU64(table_pa + idx * 8ULL, desc)) return false;
        if ((desc & 3ULL) == 3ULL) {
            next_table_pa = desc & 0x0000FFFFFFFFF000ULL;
            return true;
        }
        if (!AllocZeroPage(ram, phys_alloc_cursor, phys_alloc_limit, next_table_pa)) {
            return false;
        }
        return ram.WriteU64(table_pa + idx * 8ULL, next_table_pa | 3ULL);
    };

    uint64_t l2_pa = 0, l3_pa = 0;
    if (!ensure_table(ttbr0_pa, l1_idx, l2_pa) ||
        !ensure_table(l2_pa, l2_idx, l3_pa)) {
        return false;
    }

    uint64_t leaf = (pa & 0x0000FFFFFFFFF000ULL) | 3ULL; // Valid L3 page
    leaf |= (1ULL << 10);                                 // AF = 1
    if (el0_access) leaf |= (1ULL << 6);                  // AP[1] = 1 (EL0 allowed)
    if (!writable) leaf |= (1ULL << 7);                   // AP[2] = 1 (Read-Only)
    if (el0_access) {
        leaf |= (1ULL << 53);                             // PXN = 1 for user pages
        if (!executable) leaf |= (1ULL << 54);            // UXN = 1 when non-exec
    } else {
        leaf |= (1ULL << 54);                             // UXN = 1 for EL1 pages
        if (!executable) leaf |= (1ULL << 53);            // PXN = 1 when non-exec
    }
    return ram.WriteU64(l3_pa + l3_idx * 8ULL, leaf);
}

Elf64LoadResult Elf64GuestLoader::LoadAndMap(GuestRam& ram,
                                             uint64_t ttbr0_pa,
                                             uint64_t& phys_alloc_cursor,
                                             uint64_t phys_alloc_limit,
                                             const std::vector<uint8_t>& elf_bytes,
                                             const std::vector<std::string>& argv,
                                             const std::vector<std::string>& envp) {
    return LoadAndMap(ram, ttbr0_pa, phys_alloc_cursor, phys_alloc_limit, elf_bytes, argv, envp, {});
}

Elf64LoadResult Elf64GuestLoader::LoadAndMap(GuestRam& ram,
                                             uint64_t ttbr0_pa,
                                             uint64_t& phys_alloc_cursor,
                                             uint64_t phys_alloc_limit,
                                             const std::vector<uint8_t>& elf_bytes,
                                             const std::vector<std::string>& argv,
                                             const std::vector<std::string>& envp,
                                             const FileResolverFn& interp_resolver) {
    Elf64LoadResult res;
    if (!IsValidAArch64Elf(elf_bytes)) {
        res.error = "Invalid or non-AArch64 ELF64 binary";
        return res;
    }

    Elf64Ehdr eh{};
    std::memcpy(&eh, elf_bytes.data(), sizeof(eh));
    if (eh.e_phnum == 0 || eh.e_phentsize < sizeof(Elf64Phdr) ||
        eh.e_phoff + static_cast<uint64_t>(eh.e_phnum) * eh.e_phentsize > elf_bytes.size()) {
        res.error = "Corrupt ELF64 program header table";
        return res;
    }

    const uint64_t load_bias = (eh.e_type == kElfEtDyn) ? 0x0000000000400000ULL : 0ULL;
    uint64_t highest_va = load_bias + 0x10000ULL;
    uint64_t first_pt_load_va = 0;
    bool has_pt_load = false;

    for (uint16_t i = 0; i < eh.e_phnum; ++i) {
        Elf64Phdr ph{};
        std::memcpy(&ph, elf_bytes.data() + eh.e_phoff + static_cast<size_t>(i) * eh.e_phentsize, sizeof(ph));
        if (ph.p_type == kPtTls) {
            res.has_tls = true;
        } else if (ph.p_type == kPtInterp && ph.p_filesz > 1u &&
                   ph.p_offset + ph.p_filesz <= elf_bytes.size()) {
            res.is_dynamic = true;
            std::string raw(reinterpret_cast<const char*>(elf_bytes.data() + ph.p_offset),
                            static_cast<size_t>(ph.p_filesz));
            while (!raw.empty() && raw.back() == '\0') raw.pop_back();
            res.interp_path = raw;
        }
    }

    if (!MapElfSegments(ram, ttbr0_pa, phys_alloc_cursor, phys_alloc_limit, elf_bytes, eh,
                        load_bias, first_pt_load_va, has_pt_load, highest_va, res.error)) {
        return res;
    }

    uint64_t start_pc = load_bias + eh.e_entry;
    if (res.is_dynamic && !res.interp_path.empty()) {
        std::vector<uint8_t> interp_bytes;
        if (!interp_resolver || !interp_resolver(res.interp_path, interp_bytes)) {
            res.error = "Dynamic ELF64 requires interpreter " + res.interp_path +
                        " (not found in ramdisk or system.img)";
            return res;
        }
        if (!IsValidAArch64Elf(interp_bytes)) {
            res.error = "Invalid AArch64 ELF64 dynamic linker: " + res.interp_path;
            return res;
        }
        Elf64Ehdr interp_eh{};
        std::memcpy(&interp_eh, interp_bytes.data(), sizeof(interp_eh));
        if (interp_eh.e_phnum == 0 || interp_eh.e_phentsize < sizeof(Elf64Phdr) ||
            interp_eh.e_phoff + static_cast<uint64_t>(interp_eh.e_phnum) * interp_eh.e_phentsize >
                interp_bytes.size()) {
            res.error = "Corrupt dynamic linker program header table";
            return res;
        }
        const uint64_t interp_bias = (interp_eh.e_type == kElfEtDyn) ? kInterpLoadBase : 0ULL;
        uint64_t interp_first = 0ULL;
        bool interp_has_load = false;
        uint64_t interp_high = interp_bias;
        if (!MapElfSegments(ram, ttbr0_pa, phys_alloc_cursor, phys_alloc_limit, interp_bytes,
                            interp_eh, interp_bias, interp_first, interp_has_load,
                            interp_high, res.error)) {
            return res;
        }
        res.interp_base = interp_bias;
        start_pc = interp_bias + interp_eh.e_entry;
    }

    // Allocate 64 KiB EL0 user stack near top of 32-bit user VA space (0x7FFE0000..0x7FFF0000)
    constexpr uint64_t kUserStackTop = 0x000000007FFF0000ULL;
    constexpr uint64_t kUserStackSize = 64ULL * 1024ULL;
    const uint64_t stack_bottom = kUserStackTop - kUserStackSize;
    std::unordered_map<uint64_t, uint64_t> stack_pages;
    for (uint64_t va = stack_bottom; va < kUserStackTop; va += 4096ULL) {
        uint64_t pa = 0;
        if (!AllocZeroPage(ram, phys_alloc_cursor, phys_alloc_limit, pa) ||
            !MapPage4K(ram, ttbr0_pa, phys_alloc_cursor, phys_alloc_limit,
                       va, pa, true, true, false)) {
            res.error = "Out of guest RAM while mapping EL0 user stack";
            return res;
        }
        stack_pages[va] = pa;
    }

    auto write_stack = [&](uint64_t va, const void* src, size_t len) -> bool {
        size_t off = 0;
        while (off < len) {
            uint64_t cur = va + off;
            uint64_t pg = AlignDown4K(cur);
            size_t in_pg = static_cast<size_t>(cur - pg);
            size_t chunk = std::min(4096u - in_pg, len - off);
            if (!ram.WriteBytes(stack_pages.at(pg) + in_pg,
                                static_cast<const uint8_t*>(src) + off, chunk)) {
                return false;
            }
            off += chunk;
        }
        return true;
    };

    // Build Linux AArch64 initial user stack: strings + AT_RANDOM + auxv + envp + argv + argc
    uint64_t sp = kUserStackTop - 16ULL;
    uint8_t rand16[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
    sp -= 16ULL;
    uint64_t random_va = sp;
    write_stack(random_va, rand16, sizeof(rand16));

    std::vector<uint64_t> env_vas;
    for (const auto& s : envp) {
        sp -= (s.size() + 1u);
        write_stack(sp, s.c_str(), s.size() + 1u);
        env_vas.push_back(sp);
    }
    std::vector<uint64_t> arg_vas;
    for (const auto& s : argv) {
        sp -= (s.size() + 1u);
        write_stack(sp, s.c_str(), s.size() + 1u);
        arg_vas.push_back(sp);
    }

    sp &= ~15ULL; // 16-byte AArch64 SP alignment
    std::vector<uint64_t> words;
    words.push_back(argv.size());
    for (uint64_t p : arg_vas) words.push_back(p);
    words.push_back(0ULL);
    for (uint64_t p : env_vas) words.push_back(p);
    words.push_back(0ULL);

    const uint64_t phdr_va = has_pt_load ? (first_pt_load_va + eh.e_phoff) : 0ULL;
    auto push_aux = [&](uint64_t key, uint64_t val) {
        words.push_back(key);
        words.push_back(val);
    };
    push_aux(3u, phdr_va);                 // AT_PHDR
    push_aux(4u, eh.e_phentsize);          // AT_PHENT
    push_aux(5u, eh.e_phnum);              // AT_PHNUM
    push_aux(6u, 4096ULL);                 // AT_PAGESZ
    push_aux(7u, res.interp_base);         // AT_BASE
    push_aux(8u, 0ULL);                    // AT_FLAGS
    push_aux(9u, load_bias + eh.e_entry);  // AT_ENTRY
    push_aux(11u, 0ULL);                   // AT_UID
    push_aux(12u, 0ULL);                   // AT_EUID
    push_aux(13u, 0ULL);                   // AT_GID
    push_aux(14u, 0ULL);                   // AT_EGID
    push_aux(17u, 100ULL);                 // AT_CLKTCK
    push_aux(23u, 0ULL);                   // AT_SECURE
    push_aux(25u, random_va);              // AT_RANDOM
    if (!arg_vas.empty()) {
        push_aux(31u, arg_vas.front());    // AT_EXECFN
    }
    push_aux(0u, 0ULL);                    // AT_NULL

    const uint64_t table_bytes = words.size() * sizeof(uint64_t);
    sp = (sp - table_bytes) & ~15ULL;
    if (!write_stack(sp, words.data(), table_bytes)) {
        res.error = "Failed writing initial EL0 stack frame";
        return res;
    }

    res.ok = true;
    res.entry_pc = start_pc;
    res.phdr_va = phdr_va;
    res.phent_size = eh.e_phentsize;
    res.phnum = eh.e_phnum;
    res.brk_start = highest_va;
    res.stack_top = kUserStackTop;
    res.initial_sp = sp;
    return res;
}

// =========================================================================
// LinuxGuestSupervisor (Multi-Process EL1 Trap & Linux ARM64 SVC Engine)
// =========================================================================

LinuxGuestSupervisor::LinuxGuestSupervisor(GuestRam& ram,
                                           Pl011Uart& uart,
                                           PsciController& psci,
                                           const loader::Ext4Reader* ext4,
                                           VirtioGpuDevice* gpu,
                                           VirtioInputDevice* touch,
                                           VirtioInputDevice* kbd)
    : ram_(ram), uart_(uart), psci_(psci), ext4_(ext4), gpu_(gpu), touch_(touch), kbd_(kbd) {}

LinuxGuestSupervisor::~LinuxGuestSupervisor() {
    CloseAllOpenFds();
}

void LinuxGuestSupervisor::CloseTaskOpenFds(GuestTask& task) {
    for (auto& kv : task.open_fds) {
        if (kv.second.host_fd >= 0) {
            ::close(kv.second.host_fd);
            kv.second.host_fd = -1;
        }
    }
    task.open_fds.clear();
}

void LinuxGuestSupervisor::CloseAllOpenFds() {
    for (auto& t : tasks_) {
        if (t) CloseTaskOpenFds(*t);
    }
    for (auto& kv : open_fds_) {
        if (kv.second.host_fd >= 0) {
            ::close(kv.second.host_fd);
            kv.second.host_fd = -1;
        }
    }
    open_fds_.clear();
}

LinuxGuestSupervisor::GuestTask* LinuxGuestSupervisor::CurrentTask() {
    if (tasks_.empty() || current_task_idx_ >= tasks_.size()) return nullptr;
    return tasks_[current_task_idx_].get();
}

const LinuxGuestSupervisor::GuestTask* LinuxGuestSupervisor::CurrentTask() const {
    if (tasks_.empty() || current_task_idx_ >= tasks_.size()) return nullptr;
    return tasks_[current_task_idx_].get();
}

size_t LinuxGuestSupervisor::ActiveTaskCount() const {
    size_t count = 0;
    for (const auto& t : tasks_) {
        if (t && t->state != TaskState::Zombie) ++count;
    }
    return count;
}

void LinuxGuestSupervisor::SaveTaskContext(const CpuState& st, GuestTask& task) const {
    std::memcpy(task.cpu.x, st.x, sizeof(task.cpu.x));
    task.cpu.sp_el0 = st.sp_el[0];
    task.cpu.elr_el1 = st.sys.elr_el1;
    task.cpu.spsr_el1 = st.sys.spsr_el1;
    task.cpu.tpidr_el0 = st.sys.tpidr_el0;
    task.cpu.fpcr = st.fpcr;
    task.cpu.fpsr = st.fpsr;
    task.cpu.v = st.v;
    task.uid = uid_;
    task.gid = gid_;
    task.current_brk = current_brk_;
    task.mmap_cursor = mmap_cursor_;
    task.ttbr0_pa = ttbr0_pa_;
    task.binary = active_binary_;
}

void LinuxGuestSupervisor::RestoreTaskContext(AArch64CpuCore& cpu,
                                                CpuState& st,
                                                const GuestTask& task) const {
    const uint64_t new_ttbr0 = (task.ttbr0_pa & 0x0000FFFFFFFFF000ULL) |
                               (static_cast<uint64_t>(task.pid & 0xFFFFu) << 48);
    if (st.sys.ttbr0_el1 != new_ttbr0) {
        cpu.Mmu().InvalidateAll();
        cpu.Cache().InvalidateAll();
    }
    std::memcpy(st.x, task.cpu.x, sizeof(st.x));
    st.sp_el[0] = task.cpu.sp_el0;
    st.sys.elr_el1 = task.cpu.elr_el1;
    st.sys.spsr_el1 = task.cpu.spsr_el1;
    st.sys.tpidr_el0 = task.cpu.tpidr_el0;
    st.sys.ttbr0_el1 = new_ttbr0;
    st.fpcr = task.cpu.fpcr;
    st.fpsr = task.cpu.fpsr;
    st.v = task.cpu.v;
    st.waiting_for_interrupt = false;
}

void LinuxGuestSupervisor::WakeSleepingTasks() {
    const int64_t now = NowSteadyNs();
    for (auto& t : tasks_) {
        if (t && t->state == TaskState::Sleeping && now >= t->wakeup_ns) {
            t->state = TaskState::Runnable;
        }
    }
}

void LinuxGuestSupervisor::ResumeIfWaiting(AArch64CpuCore& cpu) {
    WakeSleepingTasks();
    CpuState& st = cpu.State();
    if (!st.waiting_for_interrupt || tasks_.empty()) return;

    const size_t n = tasks_.size();
    for (size_t step = 0; step < n; ++step) {
        const size_t cand_idx = (current_task_idx_ + step) % n;
        GuestTask* cand = tasks_[cand_idx].get();
        if (cand && cand->state == TaskState::Runnable) {
            if (cand_idx != current_task_idx_) {
                current_task_idx_ = cand_idx;
                uid_ = cand->uid;
                gid_ = cand->gid;
                current_brk_ = cand->current_brk;
                mmap_cursor_ = cand->mmap_cursor;
                ttbr0_pa_ = cand->ttbr0_pa;
                active_binary_ = cand->binary;
                RestoreTaskContext(cpu, st, *cand);
                st.pc = cand->cpu.elr_el1;
                st.pstate.UnpackSpsr(static_cast<uint32_t>(cand->cpu.spsr_el1));
            }
            st.waiting_for_interrupt = false;
            return;
        }
    }
}

void LinuxGuestSupervisor::YieldTimeSlice(AArch64CpuCore& cpu) {
    CpuState& st = cpu.State();
    if (st.halted || st.waiting_for_interrupt || st.pstate.el != 0 || tasks_.size() <= 1u) {
        return;
    }
    WakeSleepingTasks();
    GuestTask* cur = CurrentTask();
    if (!cur || cur->state != TaskState::Runnable) return;

    const size_t n = tasks_.size();
    for (size_t step = 1; step < n; ++step) {
        const size_t cand_idx = (current_task_idx_ + step) % n;
        GuestTask* cand = tasks_[cand_idx].get();
        if (cand && cand->state == TaskState::Runnable) {
            SaveTaskContext(st, *cur);
            cur->cpu.elr_el1 = st.pc;
            cur->cpu.spsr_el1 = st.pstate.PackSpsr();

            current_task_idx_ = cand_idx;
            uid_ = cand->uid;
            gid_ = cand->gid;
            current_brk_ = cand->current_brk;
            mmap_cursor_ = cand->mmap_cursor;
            ttbr0_pa_ = cand->ttbr0_pa;
            active_binary_ = cand->binary;
            RestoreTaskContext(cpu, st, *cand);
            st.pc = cand->cpu.elr_el1;
            st.pstate.UnpackSpsr(static_cast<uint32_t>(cand->cpu.spsr_el1));
            return;
        }
    }
}

bool LinuxGuestSupervisor::ScheduleNextTask(AArch64CpuCore& cpu,
                                            CpuState& st,
                                            bool& out_all_exited,
                                            bool& out_wfi_sleep) {
    out_all_exited = false;
    out_wfi_sleep = false;
    if (tasks_.empty()) {
        out_all_exited = exited_;
        return false;
    }

    WakeSleepingTasks();

    const size_t n = tasks_.size();
    for (size_t step = 1; step <= n; ++step) {
        const size_t cand_idx = (current_task_idx_ + step) % n;
        GuestTask* cand = tasks_[cand_idx].get();
        if (cand && cand->state == TaskState::Runnable) {
            if (cand_idx != current_task_idx_) {
                current_task_idx_ = cand_idx;
                uid_ = cand->uid;
                gid_ = cand->gid;
                current_brk_ = cand->current_brk;
                mmap_cursor_ = cand->mmap_cursor;
                ttbr0_pa_ = cand->ttbr0_pa;
                active_binary_ = cand->binary;
                RestoreTaskContext(cpu, st, *cand);
            } else {
                st.waiting_for_interrupt = false;
            }
            return true;
        }
    }

    // Check if any non-zombie task still waits (Sleeping / WaitingChild)
    for (const auto& t : tasks_) {
        if (t && t->state != TaskState::Zombie) {
            out_wfi_sleep = true;
            return false;
        }
    }

    out_all_exited = true;
    return false;
}

void LinuxGuestSupervisor::SetInitramfs(std::vector<CpioEntry> entries) {
    initramfs_ = std::move(entries);
}

void LinuxGuestSupervisor::SetSharedStorageRoot(const std::string& host_dir) {
    shared_storage_root_ = host_dir;
    if (!shared_storage_root_.empty()) {
        GuestVfsBridge::EnsureDirectoryTree(shared_storage_root_);
    }
}

void LinuxGuestSupervisor::SetGuestIdentity(const std::string& cmdline, bool magisk_enabled) {
    cmdline_ = cmdline;
    magisk_enabled_ = magisk_enabled;
}

bool LinuxGuestSupervisor::ResolveHostStoragePath(const std::string& norm_guest_path,
                                                  std::string& out_host_path,
                                                  std::string& out_rel) const {
    return GuestVfsBridge::MapGuestStoragePath(
        shared_storage_root_, norm_guest_path, out_host_path, out_rel);
}

bool LinuxGuestSupervisor::ResolveVfsFile(const std::string& path,
                                          std::vector<uint8_t>& out_data,
                                          bool& out_is_dir,
                                          std::vector<std::string>& out_children) const {
    const std::string norm = NormalizeGuestPath(path);
    out_data.clear();
    out_children.clear();
    out_is_dir = false;

    if (norm == "/proc/cmdline") {
        std::string text = cmdline_ + "\n";
        out_data.assign(text.begin(), text.end());
        return true;
    }
    if (norm == "/proc/version") {
        std::string text = "Linux version 5.10.209-haseeb #1 SMP PREEMPT aarch64\n";
        out_data.assign(text.begin(), text.end());
        return true;
    }
    if (norm == "/dev/input") {
        out_is_dir = true;
        if (touch_) out_children.push_back("event0");
        if (kbd_) out_children.push_back("event1");
        return true;
    }
    if ((norm == "/dev/input/event0" && touch_) || (norm == "/dev/input/event1" && kbd_)) {
        return true;
    }

    if (GuestVfsBridge::TryResolveSpecialVfs(norm, shared_storage_root_, hardware_, prop_mgr_,
                                             ram_bytes_, out_data, out_is_dir, out_children)) {
        return true;
    }

    // 1. Check initramfs CPIO entries first
    if (norm == "/") {
        out_is_dir = true;
        for (const auto& e : initramfs_) {
            if (e.name.find('/') == std::string::npos) {
                out_children.push_back(e.name);
            }
        }
        if (ext4_ && ext4_->IsOpen()) {
            std::vector<loader::Ext4DirEntry> root_entries;
            if (ext4_->ReadDir("/", root_entries)) {
                for (const auto& re : root_entries) {
                    if (re.name != "." && re.name != "..") out_children.push_back(re.name);
                }
            }
        }
        return true;
    }

    const std::string rel = norm.substr(1);
    if (const CpioEntry* ce = CpioArchive::FindEntry(initramfs_, rel)) {
        if (ce->IsDirectory()) {
            out_is_dir = true;
            std::string prefix = rel + "/";
            for (const auto& item : initramfs_) {
                if (item.name.rfind(prefix, 0) == 0) {
                    std::string tail = item.name.substr(prefix.size());
                    if (!tail.empty() && tail.find('/') == std::string::npos) {
                        out_children.push_back(tail);
                    }
                }
            }
        } else {
            out_data = ce->data;
        }
        return true;
    }

    // 2. Fallback to mount-free Ext4Reader system image (both SAR and partition-root layouts)
    if (ext4_ && ext4_->IsOpen()) {
        auto try_ext4 = [&](const std::string& p) -> bool {
            loader::Ext4Stat st{};
            if (!ext4_->Stat(p, st)) return false;
            if (st.IsDirectory()) {
                out_is_dir = true;
                std::vector<loader::Ext4DirEntry> entries;
                if (ext4_->ReadDir(p, entries)) {
                    for (const auto& de : entries) out_children.push_back(de.name);
                }
                return true;
            }
            return ext4_->ReadFile(p, out_data);
        };
        if (try_ext4(norm)) return true;
        if (norm.rfind("/system/", 0) == 0 && try_ext4(norm.substr(7))) return true;
        if (norm == "/system" && try_ext4("/")) return true;
    }
    return false;
}

bool LinuxGuestSupervisor::TryResolveElfForTask(const std::string& path,
                                                std::vector<uint8_t>& out_data) const {
    bool is_dir = false;
    std::vector<std::string> children;
    if (ResolveVfsFile(path, out_data, is_dir, children) && !is_dir &&
        Elf64GuestLoader::IsValidAArch64Elf(out_data)) {
        return true;
    }
    if (path.rfind("/system/", 0) != 0) {
        const std::string alt = "/system" + NormalizeGuestPath(path);
        if (ResolveVfsFile(alt, out_data, is_dir, children) && !is_dir &&
            Elf64GuestLoader::IsValidAArch64Elf(out_data)) {
            return true;
        }
    }
    return false;
}

bool LinuxGuestSupervisor::MapFreshAddressSpace(AArch64CpuCore& cpu,
                                                const std::vector<uint8_t>& elf_bytes,
                                                const std::vector<std::string>& argv,
                                                std::string& out_error,
                                                bool reset_phys_cursor) {
    if (reset_phys_cursor) {
        phys_cursor_ = arena_base_;
        vbar_pa_ = 0ULL;
    }

    if (!AllocZeroPage(ram_, phys_cursor_, arena_limit_, ttbr0_pa_)) {
        out_error = "Failed allocating guest TTBR0 root page";
        return false;
    }

    // Install EL1 VBAR exception trampoline page once (or after reset) and identity-map into every task TTBR0
    if (vbar_pa_ == 0ULL) {
        if (!AllocZeroPage(ram_, phys_cursor_, arena_limit_, vbar_pa_)) {
            out_error = "Failed allocating EL1 VBAR page";
            return false;
        }
        constexpr uint32_t kInsnHvcLx = 0xD4000002u | (static_cast<uint32_t>(kSyscallHypercallImm) << 5);
        constexpr uint32_t kInsnEret  = 0xD69F03E0u;
        const uint32_t trampoline[2] = {kInsnHvcLx, kInsnEret};
        ram_.WriteBytes(vbar_pa_ + 0x200ULL, trampoline, sizeof(trampoline));
        ram_.WriteBytes(vbar_pa_ + 0x400ULL, trampoline, sizeof(trampoline));
        ram_.WriteBytes(vbar_pa_ + 0x480ULL, trampoline, sizeof(trampoline));
    }
    if (!Elf64GuestLoader::MapPage4K(ram_, ttbr0_pa_, phys_cursor_, arena_limit_,
                                     vbar_pa_, vbar_pa_, false, false, true)) {
        out_error = "Failed identity-mapping EL1 VBAR";
        return false;
    }

    std::vector<std::string> envp = {
        "PATH=/sbin:/system/bin:/vendor/bin",
        "HOME=/",
        "TERM=vt100",
        magisk_enabled_ ? "HASEEB_ROOT=magisk" : "HASEEB_ROOT=0",
    };

    Elf64LoadResult load = Elf64GuestLoader::LoadAndMap(
        ram_, ttbr0_pa_, phys_cursor_, arena_limit_, elf_bytes, argv, envp,
        [this](const std::string& interp, std::vector<uint8_t>& out_bytes) {
            return TryResolveElfForTask(interp, out_bytes);
        });
    if (!load.ok) {
        out_error = load.error;
        return false;
    }

    current_brk_ = AlignUp4K(load.brk_start);
    mmap_cursor_ = 0x0000001000000000ULL;

    const int32_t active_pid = CurrentTask() ? CurrentTask()->pid : 1;
    cpu.Mmu().InvalidateAll();
    cpu.Cache().InvalidateAll();
    cpu.Reset(load.entry_pc, load.initial_sp, 0);
    auto& st = cpu.State();
    st.sp_el[0] = load.initial_sp;
    st.pstate.el = 0;
    st.pstate.spsel = false;
    st.sys.vbar_el1 = vbar_pa_;
    st.sys.ttbr0_el1 = (ttbr0_pa_ & 0x0000FFFFFFFFF000ULL) |
                       (static_cast<uint64_t>(active_pid & 0xFFFFu) << 48);
    st.sys.tcr_el1 = 25ULL | (1ULL << 23); // T0SZ=25 (39-bit VA, 4K), EPD1=1
    st.sys.mair_el1 = 0xFFULL;
    st.sys.cpacr_el1 = (3ULL << 20);
    st.sys.sctlr_el1 = 0x30D00801ULL; // MMU enabled (M=1)
    st.x[0] = 0;
    return true;
}

VmError LinuxGuestSupervisor::PrepareBoot(AArch64CpuCore& cpu,
                                          uint64_t ram_bytes,
                                          uint64_t kernel_reserved_end,
                                          const std::vector<std::string>& argv,
                                          std::string& out_selected_binary,
                                          std::string& out_error,
                                          uint64_t arena_max_limit) {
    ram_bytes_ = ram_bytes;
    arena_base_ = std::max<uint64_t>(kGuestRamBase + 0x00200000ULL, AlignUp4K(kernel_reserved_end));
    const uint64_t ram_top = kGuestRamBase + ram_bytes;
    const uint64_t default_top = ram_top - std::min<uint64_t>(ram_bytes / 4u, 0x00400000ULL);
    arena_limit_ = (arena_max_limit > 0ULL && arena_max_limit < default_top)
                       ? AlignDown4K(arena_max_limit)
                       : default_top;
    if (arena_limit_ <= arena_base_ + 0x00200000ULL) {
        out_error = "Insufficient guest RAM for EL0 init address space";
        return VmError::OutOfMemory;
    }

    exited_ = false;
    exit_status_ = 0;
    uid_ = 0u;
    gid_ = 0u;
    last_trap_detail_.clear();
    binder_services_.clear();
    CloseAllOpenFds();
    tasks_.clear();
    current_task_idx_ = 0;
    next_pid_ = 1;
    fb_mapped_pas_.clear();
    next_fd_ = 3;

    // Priority order matching Android/Magisk boot flow: /magiskinit -> /init -> /system/bin/init -> /system/bin/sh
    std::vector<std::string> candidates;
    if (magisk_enabled_) candidates.push_back("/magiskinit");
    candidates.push_back("/init");
    if (!magisk_enabled_) candidates.push_back("/magiskinit");
    candidates.push_back("/system/bin/init");
    candidates.push_back("/system/bin/sh");

    std::vector<uint8_t> elf_bytes;
    std::string chosen;
    for (const auto& path : candidates) {
        std::vector<uint8_t> data;
        bool is_dir = false;
        std::vector<std::string> children;
        if (ResolveVfsFile(path, data, is_dir, children) && !is_dir &&
            Elf64GuestLoader::IsValidAArch64Elf(data)) {
            elf_bytes = std::move(data);
            chosen = path;
            break;
        }
    }

    if (chosen.empty()) {
        out_error = "No valid AArch64 ELF64 init/magiskinit/sh binary found in initramfs or system.img";
        return VmError::FileNotFound;
    }

    std::vector<std::string> eff_argv = argv;
    if (eff_argv.empty()) eff_argv.push_back(chosen);
    active_binary_ = chosen;
    out_selected_binary = chosen;

    auto root = std::make_unique<GuestTask>();
    root->pid = next_pid_++;
    root->ppid = 0;
    root->uid = 0u;
    root->gid = 0u;
    root->binary = chosen;
    root->state = TaskState::Runnable;
    tasks_.push_back(std::move(root));
    current_task_idx_ = 0;

    if (!MapFreshAddressSpace(cpu, elf_bytes, eff_argv, out_error, true)) {
        tasks_.clear();
        return VmError::ExecutionTrap;
    }
    SaveTaskContext(cpu.State(), *tasks_[0]);
    return VmError::Ok;
}

bool LinuxGuestSupervisor::ReadUserBytes(AArch64CpuCore& cpu,
                                         uint64_t uva,
                                         void* dst,
                                         size_t len) const {
    auto* out = static_cast<uint8_t*>(dst);
    for (size_t i = 0; i < len; ++i) {
        MmuTranslationResult tr = cpu.Mmu().Translate(cpu.State(), uva + i, MemAccessType::Read, false);
        if (!tr.ok || !ram_.ReadBytes(tr.phys_addr, out + i, 1)) return false;
    }
    return true;
}

bool LinuxGuestSupervisor::WriteUserBytes(AArch64CpuCore& cpu,
                                          uint64_t uva,
                                          const void* src,
                                          size_t len) const {
    const auto* in = static_cast<const uint8_t*>(src);
    for (size_t i = 0; i < len; ++i) {
        MmuTranslationResult tr = cpu.Mmu().Translate(cpu.State(), uva + i, MemAccessType::Write, false);
        if (!tr.ok || !ram_.WriteBytes(tr.phys_addr, in + i, 1)) return false;
    }
    return true;
}

bool LinuxGuestSupervisor::ReadUserString(AArch64CpuCore& cpu,
                                          uint64_t uva,
                                          std::string& out_str) const {
    out_str.clear();
    for (size_t i = 0; i < 4096u; ++i) {
        char ch = 0;
        if (!ReadUserBytes(cpu, uva + i, &ch, 1)) return false;
        if (ch == '\0') return true;
        out_str.push_back(ch);
    }
    return false;
}

bool LinuxGuestSupervisor::FlushFramebufferToGpu() {
    GuestTask* cur = CurrentTask();
    const auto& fb_pas = cur ? cur->fb_mapped_pas : fb_mapped_pas_;
    if (!gpu_ || fb_pas.empty()) return false;
    const uint32_t w = gpu_->DisplayWidth();
    const uint32_t h = gpu_->DisplayHeight();
    if (w == 0u || h == 0u) return false;

    const size_t need_bytes = static_cast<size_t>(w) * h * 4u;
    std::vector<uint8_t> rgba(need_bytes, 0u);
    size_t offset = 0u;
    for (uint64_t pa : fb_pas) {
        if (offset >= need_bytes) break;
        const size_t chunk = std::min<size_t>(4096u, need_bytes - offset);
        if (!ram_.ReadBytes(pa, rgba.data() + offset, chunk)) {
            return false;
        }
        offset += chunk;
    }
    return gpu_->SubmitRawRgbaFrame(rgba.data(), w, h, w * 4u);
}

std::string LinuxGuestSupervisor::FormatExceptionTrap(AArch64CpuCore& cpu,
                                                      const CpuState& state,
                                                      uint32_t ec_val) const {
    uint32_t opcode = 0u;
    const bool has_opc = ReadUserBytes(cpu, state.sys.elr_el1, &opcode, sizeof(opcode));
    const GuestTask* cur = CurrentTask();
    const int32_t pid = cur ? cur->pid : 1;
    std::ostringstream oss;
    oss << ExceptionClassName(ec_val)
        << " (ec=0x" << std::hex << std::uppercase << std::setw(2) << std::setfill('0') << ec_val << ")"
        << " bin=" << (active_binary_.empty() ? "unknown" : active_binary_)
        << " pid=" << std::dec << pid
        << " ELR=0x" << std::hex << state.sys.elr_el1
        << " FAR=0x" << state.sys.far_el1
        << " SP=0x" << state.sp_el[0]
        << " LR=0x" << state.x[30];
    if (has_opc) {
        oss << " op=0x" << std::setw(8) << std::setfill('0') << opcode;
    }
    oss << " insns=" << std::dec << state.instructions_executed;
    return oss.str();
}

int64_t LinuxGuestSupervisor::DispatchSyscall(AArch64CpuCore& cpu,
                                              CpuState& st,
                                              bool& out_halt,
                                              bool& out_retry,
                                              bool& out_yield) {
    out_halt = false;
    out_retry = false;
    out_yield = false;
    const uint64_t nr = st.x[8];

    GuestTask* cur = CurrentTask();
    auto& fds = cur ? cur->open_fds : open_fds_;
    int& next_fd = cur ? cur->next_fd : next_fd_;
    auto& fb_pas = cur ? cur->fb_mapped_pas : fb_mapped_pas_;

    switch (nr) {
        case 17: { // getcwd(buf, size)
            uint64_t buf = st.x[0];
            uint64_t sz = st.x[1];
            const char cwd[] = "/";
            if (sz < sizeof(cwd)) return -34; // ERANGE
            return WriteUserBytes(cpu, buf, cwd, sizeof(cwd)) ? static_cast<int64_t>(buf) : -14;
        }
        case 24: { // dup3(oldfd, newfd, flags)
            int oldfd = static_cast<int>(st.x[0]);
            int newfd = static_cast<int>(st.x[1]);
            if (oldfd == newfd) return -22;
            if (oldfd <= 2) return newfd;
            auto it = fds.find(oldfd);
            if (it == fds.end()) return -9;
            auto existing = fds.find(newfd);
            if (existing != fds.end()) {
                if (existing->second.host_fd >= 0) ::close(existing->second.host_fd);
                fds.erase(existing);
            }
            OpenFile copy = it->second;
            if (copy.host_fd >= 0) {
                copy.host_fd = ::dup(copy.host_fd);
                if (copy.host_fd < 0) return -static_cast<int64_t>(errno);
            }
            fds.emplace(newfd, std::move(copy));
            if (next_fd <= newfd) next_fd = newfd + 1;
            return newfd;
        }
        case 25: // fcntl
            return 0;
        case 34: { // mkdirat(dirfd, pathname, mode)
            std::string path;
            if (!ReadUserString(cpu, st.x[1], path)) return -14;
            const std::string norm = NormalizeGuestPath(path);
            std::string host_path, rel;
            if (!ResolveHostStoragePath(norm, host_path, rel)) return -13; // EACCES
            GuestVfsBridge::EnsureDirectoryTree(shared_storage_root_);
            if (::mkdir(host_path.c_str(), static_cast<mode_t>(st.x[2] ? st.x[2] : 0755)) != 0) {
                if (errno == EEXIST) return 0;
                return -static_cast<int64_t>(errno);
            }
            return 0;
        }
        case 35: { // unlinkat(dirfd, pathname, flags)
            std::string path;
            if (!ReadUserString(cpu, st.x[1], path)) return -14;
            const std::string norm = NormalizeGuestPath(path);
            std::string host_path, rel;
            if (!ResolveHostStoragePath(norm, host_path, rel) || rel.empty()) return -13;
            const bool rm_dir = (st.x[2] & 0x200ULL) != 0ULL; // AT_REMOVEDIR
            const int rc = rm_dir ? ::rmdir(host_path.c_str()) : ::unlink(host_path.c_str());
            return (rc == 0) ? 0 : -static_cast<int64_t>(errno);
        }
        case 38: { // renameat(olddirfd, oldpath, newdirfd, newpath)
            std::string old_p, new_p;
            if (!ReadUserString(cpu, st.x[1], old_p) ||
                !ReadUserString(cpu, st.x[3], new_p)) return -14;
            std::string h_old, r_old, h_new, r_new;
            if (!ResolveHostStoragePath(NormalizeGuestPath(old_p), h_old, r_old) ||
                !ResolveHostStoragePath(NormalizeGuestPath(new_p), h_new, r_new)) {
                return -18; // EXDEV
            }
            return (::rename(h_old.c_str(), h_new.c_str()) == 0) ? 0 : -static_cast<int64_t>(errno);
        }
        case 46: { // ftruncate(fd, length)
            int fd = static_cast<int>(st.x[0]);
            auto it = fds.find(fd);
            if (it == fds.end() || it->second.host_fd < 0) return -9;
            return (::ftruncate(it->second.host_fd, static_cast<off_t>(st.x[1])) == 0)
                       ? 0
                       : -static_cast<int64_t>(errno);
        }
        case 59: { // pipe2(pipefd[2], flags)
            int pfds[2]{-1, -1};
            if (::pipe(pfds) != 0) return -static_cast<int64_t>(errno);
            if (st.x[1] & 04000ULL) {
                ::fcntl(pfds[0], F_SETFL, O_NONBLOCK);
                ::fcntl(pfds[1], F_SETFL, O_NONBLOCK);
            }
            const int rfd = next_fd++;
            const int wfd = next_fd++;
            OpenFile rf, wf;
            rf.path = "pipe:[r]";
            rf.host_fd = pfds[0];
            rf.nonblock = (st.x[1] & 04000ULL) != 0ULL;
            wf.path = "pipe:[w]";
            wf.host_fd = pfds[1];
            wf.nonblock = (st.x[1] & 04000ULL) != 0ULL;
            fds.emplace(rfd, std::move(rf));
            fds.emplace(wfd, std::move(wf));
            int32_t out[2] = {rfd, wfd};
            if (!WriteUserBytes(cpu, st.x[0], out, sizeof(out))) return -14;
            return 0;
        }
        case 29: { // ioctl(fd, request, argp)
            int fd = static_cast<int>(st.x[0]);
            uint64_t req = st.x[1] & 0xFFFFFFFFULL;
            uint64_t arg = st.x[2];
            auto it = fds.find(fd);
            if (it != fds.end() && it->second.is_binder) {
                if (req == 0x40046205ULL) { // BINDER_SET_MAX_THREADS
                    return 0;
                }
                if (req == 0xC0046209ULL) { // BINDER_VERSION
                    int32_t ver = 8;
                    return WriteUserBytes(cpu, arg, &ver, sizeof(ver)) ? 0 : -14;
                }
                if (req == 0xC0306201ULL) { // BINDER_WRITE_READ
                    return 0;
                }
                if (req == 0x424901ULL) { // HASEEB_BINDER_ADD_SERVICE(const char* name)
                    std::string svc_name;
                    if (!ReadUserString(cpu, arg, svc_name) || svc_name.empty()) return -14;
                    if (std::find(binder_services_.begin(), binder_services_.end(), svc_name) ==
                        binder_services_.end()) {
                        binder_services_.push_back(svc_name);
                        const int32_t pid = cur ? cur->pid : 1;
                        const std::string line = "[BINDER] +service " + svc_name +
                                                 " (pid=" + std::to_string(pid) + ")\r\n";
                        for (char c : line) uart_.Write(0x000ULL, 1, static_cast<uint8_t>(c));
                    }
                    return 0;
                }
                if (req == 0x424902ULL) { // HASEEB_BINDER_LIST_COUNT
                    return static_cast<int64_t>(binder_services_.size());
                }
                return 0;
            }
            if (it != fds.end() && it->second.is_framebuffer) {
                const uint32_t w = gpu_ ? gpu_->DisplayWidth() : 720u;
                const uint32_t h = gpu_ ? gpu_->DisplayHeight() : 1560u;
                if (req == 0x4600ULL) { // FBIOGET_VSCREENINFO (160 bytes)
                    struct LinuxFbVarScreenInfo {
                        uint32_t xres, yres, xres_virtual, yres_virtual;
                        uint32_t xoffset, yoffset, bits_per_pixel, grayscale;
                        uint32_t red[3], green[3], blue[3], transp[3];
                        uint32_t nonstd, activate, height, width, accel_flags;
                        uint32_t pixclock, left_margin, right_margin, upper_margin;
                        uint32_t lower_margin, hsync_len, vsync_len, sync, vmode;
                        uint32_t rotate, colorspace, reserved[4];
                    } v{};
                    v.xres = w; v.yres = h;
                    v.xres_virtual = w; v.yres_virtual = h;
                    v.bits_per_pixel = 32u;
                    v.red[0] = 0u;    v.red[1] = 8u;
                    v.green[0] = 8u;  v.green[1] = 8u;
                    v.blue[0] = 16u;  v.blue[1] = 8u;
                    v.transp[0] = 24u; v.transp[1] = 8u;
                    return WriteUserBytes(cpu, arg, &v, sizeof(v)) ? 0 : -14;
                }
                if (req == 0x4601ULL) { // FBIOPUT_VSCREENINFO
                    return 0;
                }
                if (req == 0x4602ULL) { // FBIOGET_FSCREENINFO (68 bytes on arm64)
                    struct LinuxFbFixScreenInfo {
                        char id[16];
                        uint64_t smem_start;
                        uint32_t smem_len;
                        uint32_t type;
                        uint32_t type_aux;
                        uint32_t visual;
                        uint16_t xpanstep, ypanstep, ywrapstep;
                        uint16_t pad;
                        uint32_t line_length;
                        uint64_t mmio_start;
                        uint32_t mmio_len;
                        uint32_t accel;
                        uint16_t capabilities;
                        uint16_t reserved[2];
                    } f{};
                    std::snprintf(f.id, sizeof(f.id), "haseeb-fb");
                    f.smem_len = w * h * 4u;
                    f.visual = 2u; // FB_VISUAL_TRUECOLOR
                    f.line_length = w * 4u;
                    return WriteUserBytes(cpu, arg, &f, sizeof(f)) ? 0 : -14;
                }
                if (req == 0x4606ULL) { // FBIOPAN_DISPLAY -> scan out framebuffer to VirtioGpu
                    return FlushFramebufferToGpu() ? 0 : -5;
                }
            } else if (it != fds.end() && it->second.input_dev != nullptr) {
                VirtioInputDevice* indev = it->second.input_dev;
                const uint32_t ioc_type = static_cast<uint32_t>((req >> 8) & 0xFFu);
                const uint32_t ioc_nr = static_cast<uint32_t>(req & 0xFFu);
                const size_t ioc_size = static_cast<size_t>((req >> 16) & 0x3FFFu);
                if (ioc_type == 'E') {
                    if (ioc_nr == 0x01u) { // EVIOCGVERSION
                        uint32_t ver = 0x010001u;
                        return WriteUserBytes(cpu, arg, &ver, sizeof(ver)) ? 0 : -14;
                    }
                    if (ioc_nr == 0x02u) { // EVIOCGID
                        struct InputId { uint16_t bustype, vendor, product, version; } id{};
                        indev->GetDeviceIds(id.bustype, id.vendor, id.product, id.version);
                        return WriteUserBytes(cpu, arg, &id, sizeof(id)) ? 0 : -14;
                    }
                    if (ioc_nr == 0x06u || ioc_nr == 0x07u || ioc_nr == 0x08u) {
                        std::string s = (ioc_nr == 0x06u) ? indev->DeviceName()
                                      : (ioc_nr == 0x07u) ? indev->DevicePhys()
                                                          : indev->DeviceUniq();
                        const size_t max_len = std::min<size_t>(ioc_size > 0u ? ioc_size : 64u, s.size() + 1u);
                        std::vector<uint8_t> buf(max_len, 0u);
                        if (max_len > 1u) {
                            std::memcpy(buf.data(), s.data(), std::min(s.size(), max_len - 1u));
                        }
                        return WriteUserBytes(cpu, arg, buf.data(), buf.size())
                                   ? static_cast<int64_t>(buf.size())
                                   : -14;
                    }
                    if (ioc_nr == 0x09u) { // EVIOCGPROP(len)
                        const size_t n = std::clamp<size_t>(ioc_size, 1u, 64u);
                        std::vector<uint8_t> prop(n, 0u);
                        indev->FillPropBitmap(prop.data(), prop.size());
                        return WriteUserBytes(cpu, arg, prop.data(), prop.size())
                                   ? static_cast<int64_t>(prop.size())
                                   : -14;
                    }
                    if (ioc_nr >= 0x20u && ioc_nr <= 0x3Fu) { // EVIOCGBIT(ev, len)
                        const uint32_t ev_type = ioc_nr - 0x20u;
                        const size_t n = std::clamp<size_t>(ioc_size, 1u, 128u);
                        std::vector<uint8_t> bits(n, 0u);
                        indev->FillEventBitmap(ev_type, bits.data(), bits.size());
                        return WriteUserBytes(cpu, arg, bits.data(), bits.size())
                                   ? static_cast<int64_t>(bits.size())
                                   : -14;
                    }
                    if (ioc_nr >= 0x40u && ioc_nr <= 0x7Fu) { // EVIOCGABS(abs)
                        const uint16_t abs_code = static_cast<uint16_t>(ioc_nr - 0x40u);
                        const VirtioInputDevice::LinuxAbsInfo info = indev->GetAbsInfo(abs_code);
                        return WriteUserBytes(cpu, arg, &info, sizeof(info)) ? 0 : -14;
                    }
                    return -22; // EINVAL
                }
            } else if (it != fds.end() &&
                       (it->second.is_sensors || it->second.is_camera ||
                        it->second.is_magisk_su || it->second.is_gles)) {
                return GuestVfsBridge::HandleSpecialIoctl(
                    it->second, req, arg, hardware_, soft_gles_, gpu_, uid_, gid_, active_binary_,
                    [&](uint64_t uva, void* dst, size_t len) { return ReadUserBytes(cpu, uva, dst, len); },
                    [&](uint64_t uva, const void* src, size_t len) { return WriteUserBytes(cpu, uva, src, len); });
            }
            return 0;
        }
        case 48: // faccessat(dirfd, pathname, mode, flags)
        case 56: { // openat(dirfd, pathname, flags, mode)
            std::string path;
            if (!ReadUserString(cpu, st.x[1], path)) return -14;
            const std::string norm = NormalizeGuestPath(path);
            const uint64_t flags = st.x[2];
            const bool nonblock = (flags & 04000ULL) != 0ULL; // O_NONBLOCK
            if (norm == "/dev/fb0") {
                if (nr == 48) return 0;
                int fd = next_fd++;
                OpenFile of;
                of.path = norm;
                of.is_framebuffer = true;
                of.nonblock = nonblock;
                fds.emplace(fd, std::move(of));
                return fd;
            }
            if (norm == "/dev/binder" || norm == "/dev/hwbinder" || norm == "/dev/vndbinder") {
                if (nr == 48) return 0;
                int fd = next_fd++;
                OpenFile of;
                of.path = norm;
                of.is_binder = true;
                of.nonblock = nonblock;
                fds.emplace(fd, std::move(of));
                return fd;
            }
            if ((norm == "/dev/input/event0" && touch_) || (norm == "/dev/input/event1" && kbd_)) {
                if (nr == 48) return 0;
                int fd = next_fd++;
                OpenFile of;
                of.path = norm;
                of.nonblock = nonblock;
                of.input_dev = (norm == "/dev/input/event0") ? touch_ : kbd_;
                fds.emplace(fd, std::move(of));
                return fd;
            }
            if (norm == "/dev/haseeb_sensors" || norm == "/dev/video0" ||
                norm == "/dev/haseeb_gles" || norm == "/dev/magisk_su" ||
                norm == "/dev/snd/pcmC0D0p" || norm == "/dev/snd/pcmC0D0c") {
                if (nr == 48) return 0;
                int fd = next_fd++;
                OpenFile of;
                of.path = norm;
                of.nonblock = nonblock;
                of.is_sensors = (norm == "/dev/haseeb_sensors");
                of.is_camera = (norm == "/dev/video0");
                of.is_gles = (norm == "/dev/haseeb_gles");
                of.is_magisk_su = (norm == "/dev/magisk_su");
                of.is_snd_play = (norm == "/dev/snd/pcmC0D0p");
                of.is_snd_cap = (norm == "/dev/snd/pcmC0D0c");
                fds.emplace(fd, std::move(of));
                return fd;
            }
            // App-private host shared storage (/storage/emulated/0, /sdcard, /data/media/0)
            std::string host_path, rel;
            if (ResolveHostStoragePath(norm, host_path, rel)) {
                GuestVfsBridge::EnsureDirectoryTree(shared_storage_root_);
                struct stat hst{};
                const bool exists = (::stat(host_path.c_str(), &hst) == 0);
                if (nr == 48) {
                    return exists ? 0 : -2;
                }
                const bool want_dir = (flags & 0200000ULL /* O_DIRECTORY */) != 0ULL ||
                                      (exists && S_ISDIR(hst.st_mode));
                if (want_dir) {
                    if (!exists) return -2;
                    std::vector<std::string> children;
                    GuestVfsBridge::ListHostDirectory(host_path, children);
                    int fd = next_fd++;
                    OpenFile of;
                    of.path = norm;
                    of.host_path = host_path;
                    of.is_dir = true;
                    of.is_host_storage = true;
                    of.dir_children = std::move(children);
                    fds.emplace(fd, std::move(of));
                    return fd;
                }
                int host_flags = O_CLOEXEC;
                const uint64_t acc = flags & 3ULL;
                if (acc == 1ULL) host_flags |= O_WRONLY;
                else if (acc == 2ULL) host_flags |= O_RDWR;
                else host_flags |= O_RDONLY;
                if (flags & 0100ULL) host_flags |= O_CREAT;
                if (flags & 01000ULL) host_flags |= O_TRUNC;
                if (flags & 02000ULL) host_flags |= O_APPEND;
                if (flags & 0200ULL) host_flags |= O_EXCL;
                const mode_t mode = st.x[3] ? static_cast<mode_t>(st.x[3] & 0777u) : 0644;
                int hfd = ::open(host_path.c_str(), host_flags, mode);
                if (hfd < 0) return -static_cast<int64_t>(errno);
                int fd = next_fd++;
                OpenFile of;
                of.path = norm;
                of.host_path = host_path;
                of.host_fd = hfd;
                of.is_host_storage = true;
                of.nonblock = nonblock;
                fds.emplace(fd, std::move(of));
                return fd;
            }
            std::vector<uint8_t> data;
            bool is_dir = false;
            std::vector<std::string> children;
            if (!ResolveVfsFile(path, data, is_dir, children)) return -2; // ENOENT
            if (nr == 48) return 0;
            int fd = next_fd++;
            OpenFile of;
            of.path = norm;
            of.data = std::move(data);
            of.is_dir = is_dir;
            of.nonblock = nonblock;
            of.dir_children = std::move(children);
            fds.emplace(fd, std::move(of));
            return fd;
        }
        case 57: { // close(fd)
            int fd = static_cast<int>(st.x[0]);
            if (fd <= 2) return 0;
            auto it = fds.find(fd);
            if (it == fds.end()) return -9;
            if (it->second.host_fd >= 0) ::close(it->second.host_fd);
            fds.erase(it);
            return 0;
        }
        case 61: { // getdents64(fd, dirp, count)
            int fd = static_cast<int>(st.x[0]);
            auto it = fds.find(fd);
            if (it == fds.end()) return -9;
            return GuestVfsBridge::BuildGetDents64(
                it->second, st.x[1], static_cast<size_t>(st.x[2]),
                [&](uint64_t uva, const void* src, size_t len) { return WriteUserBytes(cpu, uva, src, len); });
        }
        case 62: { // lseek
            int fd = static_cast<int>(st.x[0]);
            auto it = fds.find(fd);
            if (it == fds.end()) return -9;
            int64_t off = static_cast<int64_t>(st.x[1]);
            int whence = static_cast<int>(st.x[2]);
            if (it->second.host_fd >= 0) {
                off_t rc = ::lseek(it->second.host_fd, static_cast<off_t>(off), whence);
                return (rc >= 0) ? static_cast<int64_t>(rc) : -static_cast<int64_t>(errno);
            }
            int64_t target = off;
            if (whence == 1) target = static_cast<int64_t>(it->second.offset) + off;
            else if (whence == 2) target = static_cast<int64_t>(it->second.data.size()) + off;
            if (target < 0) return -22;
            it->second.offset = static_cast<size_t>(target);
            return target;
        }
        case 63: { // read(fd, buf, count)
            int fd = static_cast<int>(st.x[0]);
            uint64_t buf = st.x[1];
            size_t count = static_cast<size_t>(st.x[2]);
            if (fd == 0) {
                size_t got = 0;
                while (got < count) {
                    if ((uart_.Read(0x018ULL, 4) & (1u << 4)) != 0u) break; // RXFE
                    uint8_t b = static_cast<uint8_t>(uart_.Read(0x000ULL, 4) & 0xFFu);
                    if (!WriteUserBytes(cpu, buf + got, &b, 1)) return -14;
                    ++got;
                    if (b == '\n' || b == '\r') break;
                }
                if (got == 0 && count > 0) {
                    st.waiting_for_interrupt = true;
                    st.sys.elr_el1 -= 4ULL;
                    out_retry = true;
                    return 0;
                }
                return static_cast<int64_t>(got);
            }
            auto it = fds.find(fd);
            if (it == fds.end() || it->second.is_dir) return -9;
            if (it->second.input_dev != nullptr) {
                constexpr size_t kEvSize = sizeof(VirtioInputDevice::LinuxInputEvent);
                const size_t max_events = count / kEvSize;
                if (max_events == 0u) return -22; // EINVAL
                std::vector<VirtioInputDevice::LinuxInputEvent> evs(max_events);
                const size_t got = it->second.input_dev->PopEvdevEvents(evs.data(), max_events);
                if (got == 0u) {
                    if (it->second.nonblock) return -11; // EAGAIN
                    st.waiting_for_interrupt = true;
                    st.sys.elr_el1 -= 4ULL;
                    out_retry = true;
                    return 0;
                }
                const size_t bytes = got * kEvSize;
                if (!WriteUserBytes(cpu, buf, evs.data(), bytes)) return -14;
                return static_cast<int64_t>(bytes);
            }
            if (it->second.host_fd >= 0) {
                std::vector<uint8_t> hbuf(count);
                ssize_t r = ::read(it->second.host_fd, hbuf.data(), count);
                if (r < 0) return -static_cast<int64_t>(errno);
                if (r > 0 && !WriteUserBytes(cpu, buf, hbuf.data(), static_cast<size_t>(r))) return -14;
                return static_cast<int64_t>(r);
            }
            if (it->second.is_sensors && hardware_ != nullptr) {
                const auto samples = hardware_->SampleAllSensors();
                const size_t bytes = samples.size() * sizeof(PhoneHardwareHub::SensorSample);
                const size_t n = std::min(count, bytes);
                return (n == 0u || WriteUserBytes(cpu, buf, samples.data(), n))
                           ? static_cast<int64_t>(n)
                           : -14;
            }
            if (it->second.is_camera && hardware_ != nullptr) {
                if (it->second.data.empty() || it->second.offset >= it->second.data.size()) {
                    uint64_t ts = 0;
                    uint32_t seq = 0;
                    it->second.data = hardware_->GenerateCameraFrame(ts, seq);
                    it->second.offset = 0u;
                }
                const size_t avail = it->second.data.size() - it->second.offset;
                const size_t n = std::min(count, avail);
                if (n > 0 && !WriteUserBytes(cpu, buf, it->second.data.data() + it->second.offset, n)) {
                    return -14;
                }
                it->second.offset += n;
                return static_cast<int64_t>(n);
            }
            if (it->second.is_snd_cap && snd_ != nullptr) {
                const size_t max_samples = count / sizeof(int16_t);
                if (max_samples == 0u) return -22;
                std::vector<int16_t> pcm(max_samples, 0);
                const size_t got = snd_->PopCapturePcm(pcm.data(), max_samples);
                if (got == 0u) return it->second.nonblock ? -11 : 0;
                const size_t bytes = got * sizeof(int16_t);
                return WriteUserBytes(cpu, buf, pcm.data(), bytes) ? static_cast<int64_t>(bytes) : -14;
            }
            size_t avail = (it->second.offset < it->second.data.size())
                               ? (it->second.data.size() - it->second.offset)
                               : 0u;
            size_t n = std::min(count, avail);
            if (n > 0 && !WriteUserBytes(cpu, buf, it->second.data.data() + it->second.offset, n)) {
                return -14;
            }
            it->second.offset += n;
            return static_cast<int64_t>(n);
        }
        case 64: { // write(fd, buf, count)
            int fd = static_cast<int>(st.x[0]);
            uint64_t buf = st.x[1];
            size_t count = static_cast<size_t>(st.x[2]);
            if (fd == 1 || fd == 2) {
                std::vector<uint8_t> tmp(count);
                if (count > 0 && !ReadUserBytes(cpu, buf, tmp.data(), count)) return -14;
                for (uint8_t b : tmp) uart_.Write(0x000ULL, 1, b);
                return static_cast<int64_t>(count);
            }
            auto it = fds.find(fd);
            if (it == fds.end()) return -9;
            std::vector<uint8_t> tmp(count);
            if (count > 0 && !ReadUserBytes(cpu, buf, tmp.data(), count)) return -14;
            if (it->second.host_fd >= 0) {
                ssize_t w = ::write(it->second.host_fd, tmp.data(), count);
                return (w >= 0) ? static_cast<int64_t>(w) : -static_cast<int64_t>(errno);
            }
            if (it->second.is_snd_play && snd_ != nullptr) {
                const size_t samples = count / sizeof(int16_t);
                if (samples > 0u) {
                    snd_->PushPlaybackPcm(reinterpret_cast<const int16_t*>(tmp.data()), samples);
                }
                return static_cast<int64_t>(count);
            }
            if (it->second.is_gles && soft_gles_ != nullptr) {
                return soft_gles_->ExecuteCommandStream(tmp.data(), count, gpu_)
                           ? static_cast<int64_t>(count)
                           : -22;
            }
            return -9;
        }
        case 66: { // writev(fd, iov, iovcnt)
            int fd = static_cast<int>(st.x[0]);
            uint64_t iov_va = st.x[1];
            int iovcnt = static_cast<int>(st.x[2]);
            if (fd != 1 && fd != 2) return -9;
            int64_t total = 0;
            for (int i = 0; i < iovcnt; ++i) {
                uint64_t vec[2]{};
                if (!ReadUserBytes(cpu, iov_va + static_cast<uint64_t>(i) * 16ULL, vec, 16)) return -14;
                if (vec[1] > 0) {
                    std::vector<uint8_t> tmp(static_cast<size_t>(vec[1]));
                    if (!ReadUserBytes(cpu, vec[0], tmp.data(), tmp.size())) return -14;
                    for (uint8_t b : tmp) uart_.Write(0x000ULL, 1, b);
                    total += static_cast<int64_t>(vec[1]);
                }
            }
            return total;
        }
        case 73: { // ppoll(struct pollfd* fds, nfds_t nfds, const struct timespec* tmo_p, sigmask)
            struct LinuxPollFd {
                int32_t fd;
                int16_t events;
                int16_t revents;
            };
            const uint64_t fds_va = st.x[0];
            const size_t nfds = std::min<size_t>(static_cast<size_t>(st.x[1]), 64u);
            const uint64_t tmo_va = st.x[2];
            bool zero_timeout = false;
            if (tmo_va != 0ULL) {
                int64_t ts[2]{};
                if (!ReadUserBytes(cpu, tmo_va, ts, sizeof(ts))) return -14;
                zero_timeout = (ts[0] == 0 && ts[1] == 0);
            }
            std::vector<LinuxPollFd> pfds(nfds);
            if (nfds > 0u && !ReadUserBytes(cpu, fds_va, pfds.data(), nfds * sizeof(LinuxPollFd))) {
                return -14;
            }
            int ready = 0;
            for (auto& p : pfds) {
                p.revents = 0;
                if (p.fd < 0) continue;
                bool readable = false;
                if (p.fd == 0) {
                    readable = (uart_.Read(0x018ULL, 4) & (1u << 4)) == 0u;
                } else {
                    auto f_it = fds.find(p.fd);
                    if (f_it == fds.end()) {
                        p.revents = 0x20; // POLLNVAL
                        ++ready;
                        continue;
                    }
                    if (f_it->second.input_dev != nullptr) {
                        readable = f_it->second.input_dev->HasPendingEvdev();
                    } else {
                        readable = true;
                    }
                }
                if (readable && (p.events & 1 /* POLLIN */) != 0) {
                    p.revents = 1;
                    ++ready;
                }
            }
            if (ready == 0 && !zero_timeout && nfds > 0u) {
                st.waiting_for_interrupt = true;
                st.sys.elr_el1 -= 4ULL;
                out_retry = true;
                return 0;
            }
            if (nfds > 0u && !WriteUserBytes(cpu, fds_va, pfds.data(), nfds * sizeof(LinuxPollFd))) {
                return -14;
            }
            return ready;
        }
        case 78: { // readlinkat(dirfd, pathname, buf, bufsiz)
            std::string path;
            if (!ReadUserString(cpu, st.x[1], path)) return -14;
            const std::string norm = NormalizeGuestPath(path);
            if (norm == "/proc/self/exe") {
                const std::string& bin = active_binary_.empty() ? "/init" : active_binary_;
                const size_t n = std::min(bin.size(), static_cast<size_t>(st.x[3]));
                if (n > 0u && !WriteUserBytes(cpu, st.x[2], bin.data(), n)) return -14;
                return static_cast<int64_t>(n);
            }
            return -22;
        }
        case 79: // newfstatat(dirfd, pathname, statbuf, flags)
        case 80: { // fstat(fd, statbuf)
            uint64_t stat_va = (nr == 79) ? st.x[2] : st.x[1];
            bool is_dir = false;
            uint64_t size_bytes = 0;
            if (nr == 79) {
                std::string path;
                if (!ReadUserString(cpu, st.x[1], path)) return -14;
                const std::string norm = NormalizeGuestPath(path);
                std::string host_path, rel;
                if (ResolveHostStoragePath(norm, host_path, rel)) {
                    struct stat hst{};
                    if (::stat(host_path.c_str(), &hst) != 0) return -2;
                    is_dir = S_ISDIR(hst.st_mode);
                    size_bytes = static_cast<uint64_t>(std::max<off_t>(0, hst.st_size));
                } else {
                    std::vector<uint8_t> data;
                    std::vector<std::string> children;
                    if (!ResolveVfsFile(path, data, is_dir, children)) return -2;
                    size_bytes = data.size();
                }
            } else {
                int fd = static_cast<int>(st.x[0]);
                if (fd <= 2) {
                    size_bytes = 0;
                } else {
                    auto it = fds.find(fd);
                    if (it == fds.end()) return -9;
                    is_dir = it->second.is_dir;
                    if (it->second.host_fd >= 0) {
                        struct stat hst{};
                        if (::fstat(it->second.host_fd, &hst) == 0) {
                            is_dir = S_ISDIR(hst.st_mode);
                            size_bytes = static_cast<uint64_t>(std::max<off_t>(0, hst.st_size));
                        }
                    } else {
                        size_bytes = it->second.data.size();
                    }
                }
            }
            struct LinuxStatAArch64 {
                uint64_t st_dev;
                uint64_t st_ino;
                uint32_t st_mode;
                uint32_t st_nlink;
                uint32_t st_uid;
                uint32_t st_gid;
                uint64_t st_rdev;
                uint64_t pad1;
                int64_t  st_size;
                int32_t  st_blksize;
                int32_t  pad2;
                int64_t  st_blocks;
                uint64_t sec_pad[6];
            } ks{};
            ks.st_dev = 1;
            ks.st_ino = 1;
            ks.st_mode = is_dir ? 0040755u : 0100755u;
            ks.st_nlink = 1;
            ks.st_uid = uid_;
            ks.st_gid = gid_;
            ks.st_size = static_cast<int64_t>(size_bytes);
            ks.st_blksize = 4096;
            ks.st_blocks = static_cast<int64_t>((size_bytes + 511u) / 512u);
            return WriteUserBytes(cpu, stat_va, &ks, sizeof(ks)) ? 0 : -14;
        }
        case 291: { // statx(dirfd, pathname, flags, mask, statxbuf)
            std::string path;
            if (!ReadUserString(cpu, st.x[1], path)) return -14;
            bool is_dir = false;
            uint64_t size_bytes = 0;
            const std::string norm = NormalizeGuestPath(path);
            std::string host_path, rel;
            if (ResolveHostStoragePath(norm, host_path, rel)) {
                struct stat hst{};
                if (::stat(host_path.c_str(), &hst) != 0) return -2;
                is_dir = S_ISDIR(hst.st_mode);
                size_bytes = static_cast<uint64_t>(std::max<off_t>(0, hst.st_size));
            } else {
                std::vector<uint8_t> data;
                std::vector<std::string> children;
                if (!ResolveVfsFile(path, data, is_dir, children)) return -2;
                size_bytes = data.size();
            }
            uint8_t buf[256]{};
            const uint32_t mask = 0x000007FFu; // STATX_BASIC_STATS
            const uint32_t blksize = 4096u;
            const uint16_t mode = is_dir ? 0040755u : 0100755u;
            std::memcpy(buf + 0u, &mask, 4u);
            std::memcpy(buf + 4u, &blksize, 4u);
            std::memcpy(buf + 20u, &uid_, 4u);
            std::memcpy(buf + 24u, &gid_, 4u);
            std::memcpy(buf + 28u, &mode, 2u);
            std::memcpy(buf + 40u, &size_bytes, 8u);
            return WriteUserBytes(cpu, st.x[4], buf, sizeof(buf)) ? 0 : -14;
        }
        case 82: // fsync
        case 83: { // fdatasync
            int fd = static_cast<int>(st.x[0]);
            auto it = fds.find(fd);
            if (it != fds.end() && it->second.is_framebuffer) {
                return FlushFramebufferToGpu() ? 0 : -5;
            }
            if (it != fds.end() && it->second.host_fd >= 0) {
                return (::fsync(it->second.host_fd) == 0) ? 0 : -static_cast<int64_t>(errno);
            }
            return 0;
        }
        case 93:   // exit
        case 94: { // exit_group
            const int status = static_cast<int>(st.x[0]);
            if (tasks_.size() <= 1u || cur == nullptr) {
                exit_status_ = status;
                exited_ = true;
                out_halt = true;
                return 0;
            }
            const int32_t dead_pid = cur->pid;
            const int32_t ppid = cur->ppid;
            if (cur->clear_child_tid != 0ULL) {
                uint32_t zero = 0u;
                WriteUserBytes(cpu, cur->clear_child_tid, &zero, sizeof(zero));
            }
            CloseTaskOpenFds(*cur);
            cur->state = TaskState::Zombie;
            cur->exit_status = status;

            for (auto& t : tasks_) {
                if (t && t->pid == ppid && t->state == TaskState::WaitingChild &&
                    (t->wait_target_pid == -1 || t->wait_target_pid == 0 ||
                     t->wait_target_pid == dead_pid)) {
                    t->state = TaskState::Runnable;
                }
            }
            if (dead_pid == 1 || ActiveTaskCount() == 0u) {
                exit_status_ = status;
                exited_ = true;
                out_halt = true;
                return 0;
            }
            out_yield = true;
            return 0;
        }
        case 96: { // set_tid_address(tidptr)
            if (cur) cur->clear_child_tid = st.x[0];
            return cur ? cur->pid : 1;
        }
        case 98: { // futex(uaddr, futex_op, val, timeout, uaddr2, val3)
            const uint32_t op = static_cast<uint32_t>(st.x[1]) & 0x7Fu;
            if (op == 0u) { // FUTEX_WAIT
                uint32_t cur_val = 0u;
                if (!ReadUserBytes(cpu, st.x[0], &cur_val, sizeof(cur_val))) return -14;
                if (cur_val != static_cast<uint32_t>(st.x[2])) return -11; // EAGAIN
                out_yield = true;
                return 0;
            }
            return 0; // FUTEX_WAKE / others
        }
        case 99: // set_robust_list
            return 0;
        case 101: // nanosleep(req, rem)
        case 115: { // clock_nanosleep(clockid, flags, req, rem)
            const uint64_t req_va = (nr == 101) ? st.x[0] : st.x[2];
            int64_t ts[2]{};
            if (!ReadUserBytes(cpu, req_va, ts, sizeof(ts))) return -14;
            int64_t dur_ns = ts[0] * 1000000000LL + ts[1];
            if (dur_ns < 0) return -22;
            if (dur_ns > 5000000000LL) dur_ns = 5000000000LL;
            if (cur && dur_ns > 0) {
                cur->state = TaskState::Sleeping;
                cur->wakeup_ns = NowSteadyNs() + dur_ns;
            }
            out_yield = true;
            return 0;
        }
        case 113: { // clock_gettime(clk_id, tp)
            const int64_t ns = (st.x[0] == 1ULL)
                ? std::chrono::duration_cast<std::chrono::nanoseconds>(
                      std::chrono::steady_clock::now().time_since_epoch()).count()
                : std::chrono::duration_cast<std::chrono::nanoseconds>(
                      std::chrono::system_clock::now().time_since_epoch()).count();
            int64_t tp[2] = {ns / 1000000000LL, ns % 1000000000LL};
            return WriteUserBytes(cpu, st.x[1], tp, sizeof(tp)) ? 0 : -14;
        }
        case 124: { // sched_yield
            out_yield = true;
            return 0;
        }
        case 134: // rt_sigaction
        case 135: // rt_sigprocmask
            return 0;
        case 160: { // uname(struct new_utsname* buf)
            struct LinuxUtsName {
                char sysname[65];
                char nodename[65];
                char release[65];
                char version[65];
                char machine[65];
                char domainname[65];
            } uts{};
            std::snprintf(uts.sysname, 65, "Linux");
            std::snprintf(uts.nodename, 65, "haseeb-android");
            std::snprintf(uts.release, 65, "5.10.209-haseeb");
            std::snprintf(uts.version, 65, "#1 SMP PREEMPT");
            std::snprintf(uts.machine, 65, "aarch64");
            std::snprintf(uts.domainname, 65, "localdomain");
            return WriteUserBytes(cpu, st.x[0], &uts, sizeof(uts)) ? 0 : -14;
        }
        case 167: // prctl
            return 0;
        case 172: // getpid
        case 178: // gettid
            return cur ? cur->pid : 1;
        case 173: // getppid
            return cur ? cur->ppid : 0;
        case 174: // getuid
        case 175: // geteuid
            return static_cast<int64_t>(uid_);
        case 176: // getgid
        case 177: // getegid
            return static_cast<int64_t>(gid_);
        case 198: // socket
        case 203: // connect
        case 208: // setsockopt
        case 209: // getsockopt
            return (nr == 198) ? -97 : 0; // -EAFNOSUPPORT / ok
        case 214: { // brk(addr)
            uint64_t req = st.x[0];
            if (req == 0ULL || req <= current_brk_) return static_cast<int64_t>(current_brk_);
            uint64_t end_pg = AlignUp4K(req);
            for (uint64_t va = current_brk_; va < end_pg; va += 4096ULL) {
                uint64_t pa = 0;
                if (!AllocZeroPage(ram_, phys_cursor_, arena_limit_, pa) ||
                    !Elf64GuestLoader::MapPage4K(ram_, ttbr0_pa_, phys_cursor_, arena_limit_,
                                                 va, pa, true, true, false)) {
                    return static_cast<int64_t>(current_brk_);
                }
            }
            current_brk_ = end_pg;
            return static_cast<int64_t>(req);
        }
        case 220: { // clone(flags, child_stack, ptid, tls, ctid)
            if (!cur) return -12;
            const uint64_t flags = st.x[0];
            const uint64_t child_stack = st.x[1];
            const bool share_vm = (flags & 0x00000100ULL /* CLONE_VM */) != 0ULL;

            SaveTaskContext(st, *cur);

            auto child = std::make_unique<GuestTask>();
            child->pid = next_pid_++;
            child->ppid = cur->pid;
            child->uid = uid_;
            child->gid = gid_;
            child->binary = cur->binary;
            child->current_brk = current_brk_;
            child->mmap_cursor = mmap_cursor_;
            child->stack_top = cur->stack_top;
            child->next_fd = cur->next_fd;
            child->state = TaskState::Runnable;
            child->cpu = cur->cpu;
            child->cpu.x[0] = 0ULL; // child returns 0
            if (child_stack != 0ULL) {
                child->cpu.sp_el0 = child_stack;
            }
            if ((flags & 0x00080000ULL /* CLONE_SETTLS */) != 0ULL) {
                child->cpu.tpidr_el0 = st.x[3];
            }
            if ((flags & 0x00200000ULL /* CLONE_CHILD_CLEARTID */) != 0ULL) {
                child->clear_child_tid = st.x[4];
            }
            if (share_vm) {
                child->ttbr0_pa = ttbr0_pa_;
            } else {
                uint64_t child_ttbr0 = 0ULL;
                if (!CloneUserAddressSpace(ram_, ttbr0_pa_, child_ttbr0, phys_cursor_, arena_limit_)) {
                    return -12; // ENOMEM
                }
                child->ttbr0_pa = child_ttbr0;
            }
            for (const auto& kv : cur->open_fds) {
                OpenFile dup_of = kv.second;
                if (dup_of.host_fd >= 0) {
                    dup_of.host_fd = ::dup(dup_of.host_fd);
                }
                child->open_fds.emplace(kv.first, std::move(dup_of));
            }
            if ((flags & 0x00100000ULL /* CLONE_PARENT_SETTID */) != 0ULL && st.x[2] != 0ULL) {
                int32_t cpid = child->pid;
                WriteUserBytes(cpu, st.x[2], &cpid, sizeof(cpid));
            }
            const int32_t ret_pid = child->pid;
            tasks_.push_back(std::move(child));
            return ret_pid;
        }
        case 221: { // execve(pathname, argv, envp)
            std::string path;
            if (!ReadUserString(cpu, st.x[0], path)) return -14;
            std::vector<uint8_t> elf_bytes;
            if (!TryResolveElfForTask(path, elf_bytes)) {
                return -2;
            }
            std::vector<std::string> argv = {path};
            if (st.x[1] != 0ULL) {
                argv.clear();
                for (size_t idx = 0; idx < 16u; ++idx) {
                    uint64_t ptr = 0;
                    if (!ReadUserBytes(cpu, st.x[1] + idx * 8ULL, &ptr, 8) || ptr == 0ULL) break;
                    std::string arg;
                    if (ReadUserString(cpu, ptr, arg)) argv.push_back(arg);
                }
                if (argv.empty()) argv.push_back(path);
            }
            std::string err;
            active_binary_ = path;
            const bool reset_arena = (tasks_.size() <= 1u);
            if (!MapFreshAddressSpace(cpu, elf_bytes, argv, err, reset_arena)) {
                last_trap_detail_ = "execve(" + path + ") failed: " + err;
                const std::string tmsg = "[TRAP] " + last_trap_detail_ + "\r\n";
                for (char c : tmsg) uart_.Write(0x000ULL, 1, static_cast<uint8_t>(c));
                return -8;
            }
            // Stay in EL1h so the immediately following ERET at VBAR+0x404 cleanly transitions to EL0t
            const uint64_t new_entry = st.pc;
            const uint64_t new_sp_el0 = st.sp_el[0];
            st.pstate.el = 1;
            st.pstate.spsel = true;
            st.pstate.d = true;
            st.pstate.a = true;
            st.pstate.i = true;
            st.pstate.f = true;
            st.sys.elr_el1 = new_entry;
            st.sys.spsr_el1 = 0ULL; // EL0t
            st.sp_el[0] = new_sp_el0;
            st.x[0] = 0ULL;
            if (cur) {
                SaveTaskContext(st, *cur);
            }
            return 0;
        }
        case 222: { // mmap(addr, length, prot, flags, fd, offset)
            uint64_t addr = st.x[0];
            uint64_t len = AlignUp4K(st.x[1]);
            uint64_t prot = st.x[2];
            int fd = static_cast<int>(static_cast<int32_t>(st.x[4]));
            if (len == 0ULL) return -22;
            if (addr == 0ULL) {
                addr = mmap_cursor_;
                mmap_cursor_ += len + 4096ULL;
            } else {
                addr = AlignDown4K(addr);
            }
            const bool w = (prot & 2ULL) != 0;
            const bool x = (prot & 4ULL) != 0;
            auto fd_it = (fd >= 0) ? fds.find(fd) : fds.end();
            const bool is_fb_map = (fd_it != fds.end() && fd_it->second.is_framebuffer);
            if (is_fb_map) fb_pas.clear();
            for (uint64_t va = addr; va < addr + len; va += 4096ULL) {
                uint64_t pa = 0;
                if (!AllocZeroPage(ram_, phys_cursor_, arena_limit_, pa) ||
                    !Elf64GuestLoader::MapPage4K(ram_, ttbr0_pa_, phys_cursor_, arena_limit_,
                                                 va, pa, true, w, x)) {
                    return -12; // ENOMEM
                }
                if (is_fb_map) fb_pas.push_back(pa);
            }
            return static_cast<int64_t>(addr);
        }
        case 215: // munmap
        case 226: // mprotect
            return 0;
        case 260: { // wait4(pid, wstatus, options, rusage)
            if (!cur) return -10;
            const int32_t target = static_cast<int32_t>(static_cast<int64_t>(st.x[0]));
            const uint64_t wstatus_uva = st.x[1];
            const uint64_t options = st.x[2];

            bool has_matching_child = false;
            for (size_t i = 0; i < tasks_.size(); ++i) {
                GuestTask* t = tasks_[i].get();
                if (!t || t->ppid != cur->pid) continue;
                if (target > 0 && t->pid != target) continue;
                has_matching_child = true;
                if (t->state == TaskState::Zombie) {
                    const int32_t reaped_pid = t->pid;
                    const uint32_t wstatus = static_cast<uint32_t>((t->exit_status & 0xFF) << 8);
                    if (wstatus_uva != 0ULL &&
                        !WriteUserBytes(cpu, wstatus_uva, &wstatus, sizeof(wstatus))) {
                        return -14;
                    }
                    tasks_.erase(tasks_.begin() + static_cast<std::ptrdiff_t>(i));
                    if (i < current_task_idx_) {
                        --current_task_idx_;
                    }
                    return reaped_pid;
                }
            }
            if (!has_matching_child) return -10; // ECHILD
            if ((options & 1ULL /* WNOHANG */) != 0ULL) return 0;

            cur->state = TaskState::WaitingChild;
            cur->wait_target_pid = target;
            cur->wait_status_uva = wstatus_uva;
            st.sys.elr_el1 -= 4ULL; // Retry wait4 once child wakes us
            out_retry = true;
            out_yield = true;
            return 0;
        }
        case 261: { // prlimit64(pid, resource, new_limit, old_limit)
            if (st.x[3] != 0ULL) {
                uint64_t lim[2] = {64ULL * 1024ULL * 1024ULL, 64ULL * 1024ULL * 1024ULL};
                if (!WriteUserBytes(cpu, st.x[3], lim, sizeof(lim))) return -14;
            }
            return 0;
        }
        case 278: { // getrandom(buf, buflen, flags)
            uint64_t buf = st.x[0];
            size_t len = static_cast<size_t>(st.x[1]);
            std::vector<uint8_t> rnd(len);
            std::random_device rd;
            for (size_t i = 0; i < len; ++i) rnd[i] = static_cast<uint8_t>(rd());
            return WriteUserBytes(cpu, buf, rnd.data(), len) ? static_cast<int64_t>(len) : -14;
        }
        default:
            return -38; // ENOSYS
    }
}

HypercallResult LinuxGuestSupervisor::HandleHypercall(AArch64CpuCore& cpu,
                                                      CpuState& state,
                                                      uint16_t imm16,
                                                      bool is_smc) {
    if (!is_smc && imm16 == kSyscallHypercallImm) {
        const uint32_t ec_val = static_cast<uint32_t>(state.sys.esr_el1 >> 26) & 0x3Fu;
        if (ec_val == ec::kSvc64) {
            bool halt = false;
            bool retry = false;
            bool yield = false;
            int64_t ret = DispatchSyscall(cpu, state, halt, retry, yield);
            if (!retry) {
                state.x[0] = static_cast<uint64_t>(ret);
            }
            if (halt) {
                return HypercallResult{true, true};
            }
            if (yield && !tasks_.empty()) {
                if (GuestTask* cur = CurrentTask()) {
                    SaveTaskContext(state, *cur);
                }
                bool all_exited = false;
                bool wfi_sleep = false;
                if (!ScheduleNextTask(cpu, state, all_exited, wfi_sleep)) {
                    if (all_exited) {
                        exited_ = true;
                        return HypercallResult{true, true};
                    }
                    if (wfi_sleep) {
                        state.waiting_for_interrupt = true;
                    }
                }
            }
            return HypercallResult{true, false};
        }

        // Unexpected synchronous/IRQ trap inside EL0/EL1 supervisor — decode & log fully
        last_trap_detail_ = FormatExceptionTrap(cpu, state, ec_val);
        const std::string line = "[TRAP] " + last_trap_detail_ + "\r\n";
        for (char c : line) {
            uart_.Write(0x000ULL, 1, static_cast<uint8_t>(c));
        }
        exited_ = true;
        exit_status_ = -1;
        return HypercallResult{true, true};
    }
    return psci_.HandleHypercall(state, imm16, is_smc);
}

} // namespace haseeb::vm
