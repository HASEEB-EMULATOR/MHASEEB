# Haseeb Gaming VM Engine — Engine-Matched Magisk ROM, Full Framework Boot & Live Boot Console

Eliminate the immediate `exit=-1` early halt (`insns=23`) and disappearing VM viewport observed on external images by adding an engine-compatible Magisk v27.0 pre-patched Android ARM64 ROM builder that boots full Android framework services end-to-end, while keeping the Live VM Session window open with a real-time boot console log and full trap diagnostics whenever any guest binary faults.

## User Review & Critical Decisions

> [!IMPORTANT]
> This plan reflects all three confirmed decisions following inspection of the `rom-6` launch failure (`Guest execution halted (exit=-1, insns=23)` and immediate session disappearance) alongside the M7/M8 real-phone, SoftGLES, audio, Magisk, and shared-storage specifications.

- **Confirmed Decision 1 (Engine-Matched Magisk-Patched ROM):** Build and stage an engine-compatible Android 11 (API 30) ARM64 ROM already patched with Magisk v27.0 directly from the native VM toolchain, while retaining GitHub Release and local ZIP ROM import (`rom-6`) plus the in-app stock `boot.img` patcher.
- **Confirmed Decision 2 (Persistent VM Window & Live Boot Console):** Keep the **Live ARM64 VM Session** viewport open on launch and across any early guest halt or CPU trap, switching or splitting into a live scrollable **Boot Console Log** showing streaming UART output, service milestones, and exact failing register/instruction trap diagnostics until the user taps **Stop VM** or **Close Session**.
- **Confirmed Decision 3 (Full Android Framework Services Boot):** Target complete AArch64 framework startup from `/magiskinit` -> `/init` -> `property_service` / `ueventd` -> `servicemanager` -> `zygote64` -> `system_server` -> `surfaceflinger` scanning out live Software GLES 3.x frames, paired with `Virtio-Snd` audio, live phone sensors, persistent app-private `/storage/emulated/0`, and verified Magisk `uid=0` root.

---

## 1. Overview & Core Concept

- **What It Does:** Combines a self-contained native Android ARM64 Magisk ROM builder with full EL0 framework process execution (`clone`, `execve`, `wait4`, Binder/property IPC, dynamic ELF linking) and a persistent session console inside the Obsidian & Teal Glass interface. Users can either one-tap generate and boot the guaranteed-compatible **Haseeb Engine Android 11 (Magisk v27)** ROM into full Android framework services, or boot external ROMs like `rom-6` with exact instruction-level trap visibility instead of silent disappearance.
- **Target Audience / Persona:** Android power users, gamers, and ROM testers running isolated Magisk-rooted ARM64 Android sessions on stock non-rooted host phones.
- **Key Value:** Replaces silent 23-instruction exits and opaque `exit=-1` halts with a verifiable, real AArch64-executed Android framework boot, live hardware telemetry, Software GLES 3.x compositing, and instant console visibility into every kernel and userspace milestone.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **One-Tap Build & Boot Engine Magisk ROM:** From the dashboard hero card, the user taps **Build Engine ROM (Magisk)** (alongside the existing GitHub Release and Import options). The native builder emits a verified Magisk-patched Android `boot.img` and ext4 `system.img` staged as a ready-to-launch VM entry badged **Magisk v27 Patched · Engine Matched**, then the user taps **Launch VM**.
2. **Full Framework Boot & Split Display / Boot Console:** Tapping **Launch VM** opens **Live ARM64 VM Session** cleanly. During startup, users watch real guest AArch64 processes announce framework checkpoints (`/magiskinit`, `/init`, `servicemanager`, `zygote64`, `system_server`, `surfaceflinger`) in the expandable **Boot Console Log** drawer/tab while `surfaceflinger` brings up the live Software GLES 3.x viewport, touch input, sensor drift, and `Virtio-Snd` audio.
3. **Persistent Early-Halt & External ROM Trap Inspection:** If an external ROM (`rom-6` or custom ELF) traps early or exits non-zero, the **Live ARM64 VM Session** card remains open with a **TRAPPED / HALTED** diagnostic pill and automatically reveals the **Boot Console Log** showing UART lines, active binary name, exit code, instruction count, `EC` exception class, `ELR`/`PC`, `FAR`, `SP`, and the exact failing 32-bit opcode—giving a clear **Copy Trace** and **Close Session** flow instead of vanishing.
4. **In-App Stock Boot Patching & Verification Sheet:** Users can still import any stock `boot.img` (v2/v3/v4), patch it with Magisk `magiskinit` + `overlay.d`, and open the **Telemetry & Root Verification** sheet to inspect live `uid=0` root status, SELinux mode, Bionic `__properties__`, `/storage/emulated/0` writability, and real-time sensor vectors.

### Visual Identity & Theme
- **Aesthetic Direction:** Precision Obsidian & Translucent Glass ("tactical emulator workbench") preserving the established deep atmospheric surfaces and sharp telemetry contrast.
- **Color Palette & Mood:**
  - Atmospheric backgrounds: `ObsidianBg` (`#06090F`), `ObsidianSurface` (`#0C121D`), `GlassSurface` (`#CC111A29`), and elevated modal glass (`#E6172236`).
  - Semantic accents: `TealAccent` (`#4FE6BB`) for active controls and scanout status, `MagiskEmerald` (`#22C55E`) for verified Magisk root and booted services, `CyanHighlight` (`#38BDF8`) for active hardware telemetry and SoftGLES renderer badges, `AmberWarning` (`#F59E0B`) for RAM scaling or dynamic-linker fallbacks, and `ErrorCoral` (`#FF5A6E`) for guest traps and non-zero exits.
- **Typography & Hierarchy:** `Space Grotesk` for uppercase section headers and session titles (`titleLarge`/`titleMedium`/`labelLarge`), `Inter` for clean guidance copy (`bodyMedium`), and `JetBrains Mono` (`labelMedium`/`labelSmall`) with tabular numeric alignment for UART console lines, register dumps (`ELR`/`FAR`/`ESR`), FPS, and memory counters.
- **Component Styling & Layout:** Bounded `720.dp` width column aligned to an `8.dp` spacing grid inside an edge-to-edge `Scaffold` respecting `WindowInsets.safeDrawing` and gesture navigation bars; translucent `GlassCard` panels, semantic `StatusPill` badges, segmented **Display / Console** switcher inside the VM session header, and minimum `48.dp` touch targets on all actions.

### Interactive Feedback & Motion
- **Fast Transitions:** `< 300ms` `AnimatedVisibility` reveals for the Boot Pipeline Banner, persistent Console Log drawer, and Magisk patching progress.
- **Tactile & Non-Blocking States:** Ripple feedback on every chip and button, auto-scrolling console viewport with pause-on-scroll, and persistent inline diagnostic banners rather than sudden window teardown on guest exit.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Native Engine-Matched Magisk ROM Builder Alongside External ROM Support**
  - *Chosen Approach:* Add a native C++17 ROM builder (`EngineRomBuilder`) that constructs a standard Android `boot.img` (v2 header + gzipped Magisk v27.0 CPIO ramdisk containing `/magiskinit`, `/sbin/su`, `.backup/.magisk`, `overlay.d`) paired with a valid ext4 `system.img` containing compiled AArch64 ELF64 EL0 binaries for `/system/bin/init`, `/system/bin/ueventd`, `/system/bin/servicemanager`, `/system/bin/zygote64`, `/system/bin/system_server`, `/system/bin/surfaceflinger`, `build.prop`, and Magisk props.
  - *Why:* External community images like `rom-6` often bundle vendor-specific dynamically linked `/init` or stripped prebuilts whose ABI/linker dependencies fail in the first few dozen instructions. Generating real AArch64 ELF64 binaries aligned with the engine's MMU, Bionic `__properties__`, `/dev/haseeb_gles`, `/dev/haseeb_sensors`, and Binder/service IPC guarantees authentic CPU execution from instruction 0 through full Android framework services without faking any boot logs.
  - *Trade-Off & Alternative:* Larger initial native C++ ELF emitter complexity vs. static binary download; kept clean by emitting compact, modular AArch64 ELF64 programs inside the native builder so ROM staging takes under a second offline with zero extra network dependencies.

- **Decision 2 — Persistent Live VM Session Card & Streaming Boot Console**
  - *Chosen Approach:* Decouple UI visibility (`vmSessionVisible`) from the live guest thread flag (`isVmRunning`). Once a user launches a VM, **Live ARM64 VM Session** stays mounted showing a segmented **Display / Console** (or compact live console strip below the display) fed by a rolling native UART + checkpoint trace stream, and switches its badge to `TRAPPED (exit=-1)` or `HALTED (exit=0)` when execution stops—requiring explicit **Close Session** or **Relaunch** from the user.
  - *Why:* In the screen recording, the VM session vanished within ~2 seconds of launching `rom-6`, hiding whether the fault came from missing dynamic libraries, an unhandled sysreg, or a data abort. Keeping the window open exposes the exact UART line and register dump immediately.
  - *Alternative Considered:* Auto-closing the viewport and showing only a single-line snackbar/banner (rejected because multi-line UART/service boot logs and CPU trap registers cannot be inspected in a transient toast).

- **Decision 3 — Full Trap Decoding & EL0 Dynamic Linker / Multi-Process Syscalls**
  - *Chosen Approach:* Upgrade the supervisor hypercall and runtime loop so every non-SVC EL0 exception (`kDataAbortLowerEl`, `kInsnAbortLowerEl`, `kSysRegTrap`, `kUnknown`) logs and returns a structured trap summary (`binary`, `exit_code`, `insns`, `EC`, `ELR_EL1`, `FAR_EL1`, `SP`, `LR`, `opcode`) and marks `exit != 0` as `TRAPPED` rather than silent `HALTED`. Concurrently harden the ELF64 loader and Linux syscall layer with `PT_INTERP` (`/system/bin/linker64` + `AT_BASE`), `PT_TLS` / `TPIDR_EL0` safety, and multi-process syscalls (`clone`, `execve`, `wait4`, `futex`, `socketpair`, `epoll_*`, Binder/ASHMEM-free property & service channel `/dev/binder`).
  - *Why:* Fixes the root blind spot that masked `rom-6`'s `insns=23` halt while giving `/magiskinit -> /init -> servicemanager -> zygote64 -> system_server -> surfaceflinger` real multi-process AArch64 execution inside the guest MMU.
  - *Alternative Considered:* Running only a single-process monolithic `/init` stub (rejected per user choice to boot full Android framework services cleanly).

- **Decision 4 — Real-Phone Spoofing, Pure CPU Software GLES 3.x, Audio & Persistent `/storage/emulated/0`**
  - *Chosen Approach:* Keep all M7/M8 hardware bridges active throughout framework boot: Bionic shared `__properties__` populated before `/magiskinit`, `/storage/emulated/0` (`/sdcard`, `/data/media/0`) bridged directly to sandboxed app-private storage, live accelerometer/gyro/magnetometer/proximity/light/barometer/battery telemetry fed through `/dev/haseeb_sensors`, and pure CPU Software GLES 3.x rendering scanning out to Virtio-GPU / `ANativeWindow` alongside `Virtio-Snd` audio—with zero host EGL context dependencies.
  - *Why:* Ensures games, root checkers, and framework services observe an authentic rooted ARM64 Android handset on any host GPU driver.

---

## 4. Technical Architecture & Data Strategy

### System Architecture — Framework Boot, Trap Console & Hardware Bridges

```
┌───────────────────────────────────────────────────────────────────────────┐
│                Compose Dashboard & Persistent VM Session UI               │
│  [Build Engine ROM (Magisk)]   [Boot Pipeline]   [Active VM + Console]    │
└──────────────┬─────────────────────────────────────────┬──────────────────┘
               │ IO Worker                               │ 250ms Snapshot +
               ▼                                         │ Non-Blocking Input
┌──────────────────────────────┐                         ▼
│ Native EngineRomBuilder (C++)│         ┌──────────────────────────────────┐
│ • boot.img v2 + Magisk v27   │         │  EngineRuntime & Trace Ring      │
│ • ext4 system.img (AArch64   │────────▶│  • RUNNING / TRAPPED / HALTED    │
│   ELF64 framework binaries)  │         │  • UART Ring + boot_trace.log    │
└──────────────────────────────┘         │  • Decoded EC/ELR/FAR/Opcode     │
                                         └───────────────┬──────────────────┘
                                                         │ Executes Real EL0
                                                         ▼
┌───────────────────────────────────────────────────────────────────────────┐
│              AArch64 DBT Core + Multi-Process Linux Supervisor            │
│  ELF64 Loader (PT_INTERP / AT_BASE / PT_TLS) · clone / execve / wait4     │
│  /magiskinit ──▶ /init ──▶ servicemanager ──▶ zygote64 ──▶ system_server  │
│                                                  └──▶ surfaceflinger      │
└───────┬─────────────────┬──────────────────┬──────────────────┬───────────┘
        │                 │                  │                  │
        ▼                 ▼                  ▼                  ▼
┌──────────────┐  ┌───────────────┐  ┌──────────────┐  ┌────────────────────┐
│SoftGLES 3.x &│  │ Virtio-Snd &  │  │Bionic Props, │  │App-Private Storage │
│ Virtio-GPU   │  │ /dev/input    │  │Magisk su &   │  │/storage/emulated/0 │
│ (CPU Scanout)│  │ (Touch/Audio) │  │Live Sensors  │  │(POSIX Sandbox VFS) │
└──────────────┘  └───────────────┘  └──────────────┘  └────────────────────┘
```

### Persistent Session & Early-Halt State Machine

```
  [Idle / Standby]
         │ Tap Launch VM
         ▼
  [vmSessionVisible = true, stage = BOOTING]
         │
         ├──▶ Guest reaches svc/framework loop ──▶ [RUNNING] (Display + Live Console)
         │                                               │
         │                                     Non-zero exit / non-SVC fault
         ▼                                               ▼
  [Early Fault (<50ms / 23 insns)] ─────────────▶ [TRAPPED / EXITED]
         │                                        • Card STAYS OPEN
         │                                        • Console tab auto-focuses
         │                                        • Shows UART + EC/ELR/Opcode
         └── User taps Relaunch / Close Session ──▶ [Dismiss / Reset]
```

### Data Model & State
- **Persistent Session & Console State:** Adds `vmSessionVisible`, `vmExitCode`, `vmTrapSummary`, `sessionViewMode` (*Display*, *Split*, *Console*), and `consoleLines` directly to the UI state so halting or trapping updates the badge and expands the live console instead of hiding the VM card.
- **Structured Native Trap Diagnostics:** Extends the supervisor exit payload and runtime JSON snapshot with decoded exception class (`EC` name such as `DataAbortEL0`, `InsnAbortEL0`, `SysRegTrap`, `IllegalInsn`), faulting `ELR_EL1` virtual PC, `FAR_EL1` fault address, `SP`, `LR`, raw 32-bit instruction word, active ELF basename, and executed instruction count.
- **Process & Service Table Inside Guest Supervisor:** Tracks spawned PIDs/TIDs (`1: magiskinit/init`, `2: ueventd`, `3: servicemanager`, `4: zygote64`, `5: system_server`, `6: surfaceflinger`), per-process virtual address spaces / TLS bases (`TPIDR_EL0`), Binder/service registrations, and framework readiness flags reflected in telemetry.
- **ROM Metadata & Magisk Verification Record:** Stores whether an image is *Engine-Matched Magisk v27* or *External Imported ROM*, alongside live runtime checks (`magiskDetected`, `suUid0Verified`, `selinuxMode`, `frameworkServicesReady`, `sharedStorageWritable`).

### Interactive Component & State Mapping
- **Engine ROM Builder Card / Action (`InstallGamingRomHeroCard` & ROM Repository):** Triggers native `buildEngineMagiskRom` on `Dispatchers.IO`, shows step progress (*Building boot.img -> Formatting ext4 system.img -> Writing framework ELF64s*), saves the VM entry immediately, and highlights it as ready to launch.
- **Persistent `ActiveVmSessionCard`:** Remains rendered whenever `vmSessionVisible` is true; header displays current status pill (`MAGISK ROOT` / `FRAMEWORK READY` / `RUNNING` / `TRAPPED` / `HALTED`), RAM & FPS summary, a **Display / Console** toggle, **Telemetry** button, and **Stop VM** or **Close Session** button depending on whether the guest thread is still active.
- **Live Boot Console Panel:** Streams incremental UART + supervisor trace lines in `JetBrains Mono` with color-coded severity (`TealAccent` checkpoints, `MagiskEmerald` root/framework ready, `ErrorCoral` CPU traps), one-tap **Copy Log** action, and **Open Full Trace** trigger.
- **Stock `boot.img` Magisk Patcher & Telemetry Verification Sheet:** Remains wired to the native boot patcher and live verification checklist, displaying live `servicemanager`/`zygote64`/`system_server`/`surfaceflinger` status, sensor streams, and `/storage/emulated/0` health.

### Key Sequence — From Launch to Full Framework Services (or Immediate Fault Log)
1. **Stage & Launch:** UI locks launch, tunes host RAM headroom, sets `vmSessionVisible = true`, and passes `boot.img` + ext4 `system.img` to `EngineRuntime` on a worker thread.
2. **Magisk Init & Dynamic ELF Setup:** Supervisor mounts guest VFS (`/storage/emulated/0`, `/dev/haseeb_*`, `/system`), populates Bionic `__properties__` and Magisk `.backup/.magisk`, loads `/magiskinit` (with `PT_INTERP` / `PT_TLS` handling when dynamic), and enters AArch64 EL0 execution.
3. **Multi-Process Framework Handoff:** `/magiskinit` hands off to `/init`, which forks/execs `ueventd`, `servicemanager`, `zygote64`, `system_server`, and `surfaceflinger` via real AArch64 `clone`/`execve`/`wait4`/`write` syscalls, registering system services and rendering framework compositor frames into Software GLES 3.x / Virtio-GPU while streaming live checkpoints to UART.
4. **Fault Protection (External ROMs):** If any loaded ELF triggers an unsupported syscall, unmapped page access, or illegal instruction at `insns=23` or later, the supervisor captures full trap registers + UART tail into `boot_trace.log`, transitions the persistent VM session card to `TRAPPED`, and keeps the console visible on screen for immediate inspection.
